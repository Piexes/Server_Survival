datablock ProjectileData(DCrossSpearFastProjectile)
{
   directDamage        = 17;
   directDamageType  = $DamageType::Duel_Strike;
   radiusDamageType  = $DamageType::Duel_Strike;
   stickExplosion        = BladeSmallMetalExplosion;
   bloodExplosion        = BladeMetalPlayerHitExplosion;
   explosion           = BladeSmallMetalExplosion;

   muzzleVelocity      = 65;
   velInheritFactor    = 1;
   explodeOnPlayerImpact = true;
   explodeOnDeath        = false;  

   armingDelay         = 80;
   lifetime            = 80;
   fadeDelay           = 80;
   isBallistic         = true;
   bounceAngle         = 170; //stick almost all the time
   minStickVelocity    = 10;
   bounceElasticity    = 0.2;
   bounceFriction      = 0.01;   
   gravityMod = 0.0;

   hasLight    = false;
   lightRadius = 3.0;
   lightColor  = "0 0 0.5";
};

datablock ProjectileData(DCrossSpearMediumProjectile)
{
   directDamage        = 66;
   directDamageType  = $DamageType::Duel_Strike;
   radiusDamageType  = $DamageType::Duel_Strike;
   stickExplosion        = BladeSmallMetalExplosion;
   bloodExplosion        = BladeMetalPlayerHitExplosion;
   explosion           = BladeSmallMetalExplosion;

   muzzleVelocity      = 65;
   velInheritFactor    = 1;
   explodeOnPlayerImpact = true;
   explodeOnDeath        = false;  

   armingDelay         = 80;
   lifetime            = 80;
   fadeDelay           = 80;
   isBallistic         = true;
   bounceAngle         = 170; //stick almost all the time
   minStickVelocity    = 10;
   bounceElasticity    = 0.2;
   bounceFriction      = 0.01;   
   gravityMod = 0.0;

   hasLight    = false;
   lightRadius = 3.0;
   lightColor  = "0 0 0.5";
};

//////////
// item //
//////////
datablock ItemData(DCrossSpearItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./Cross_Spear_Item.dts";
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "Duel_M_Cross Spear";
	iconName = "./Cross_Spear_Icon";
	doColorShift = true;
	colorShiftColor = "0.471 0.471 0.471 1.000";

	 // Dynamic properties defined by the scripts
	image = DCrossSpearImage;
	canDrop = true;
};

////////////////
//weapon image//
////////////////
datablock ShapeBaseImageData(DCrossSpearImage)
{
   // Basic Item properties
   shapeFile = "./Cross_Spear.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = "-0.58 -0.75 -0.285"; //X Z Y


   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = false;

   eyeOffset = 0; //"0.7 1.2 -0.1";

   // Add the WeaponImage namespace as a parent, WeaponImage namespace
   // provides some hooks into the inventory system.
   className = "WeaponImage";

   // Projectile && Ammo.
   item = DCrossSpearItem;
   ammo = " ";
   projectile = DCrossSpearFastProjectile;
   projectileType = Projectile;

   //melee particles shoot from eye node for consistancy
   melee = true;
   doRetraction = false;
   //raise your arm up or not
   armReady = true;

   //casing = " ";
   doColorShift = true;
   colorShiftColor = "0.471 0.471 0.471 1.000";

 	stateName[0]                     = "Activate";
                stateSound[0]                    = ClubDrawSound;
	stateSequence[0]                     = "Activate";
	stateTimeoutValue[0]             = 2.0;
	stateTransitionOnTimeout[0]      = "Ready1";

	stateName[1]                     = "Ready1";
	stateSequence[1]                     = "Ready1";
	stateTransitionOnTriggerDown[1]  = "Fire1Pre";
	stateAllowImageChange[1]         = true;

	stateName[2]                    = "Fire1Pre";
	stateSequence[2]                = "Ready1";
	stateTimeoutValue[2]            = 0.7;
	stateTransitionOnTimeout[2]     = "Fire5Pre";
	stateWaitForTimeout[2]		= false;
	stateTransitionOnTriggerUp[2]  = "Fire1";
	stateAllowImageChange[2]        = false;

	stateName[3]                    = "Fire1";
	stateSequence[3]                = "Fire1";
	stateTransitionOnTimeout[3]     = "Ready2";
	stateTimeoutValue[3]            = 0.35;
	stateFire[3]                    = true;
	stateAllowImageChange[3]        = false;
	stateScript[3]                  = "onFireFast";
	stateWaitForTimeout[3]		= true;

//The Second strike.

	stateName[4]                     = "Ready2";
	stateSequence[4]                     = "Ready2";
	stateTransitionOnTriggerDown[4]  = "Fire2Pre";
	stateAllowImageChange[4]         = true;

	stateName[5]                    = "Fire2Pre";
	stateSequence[5]                = "Ready2";
	stateTimeoutValue[5]            = 0.7;
	stateTransitionOnTimeout[5]     = "Fire5Pre";
	stateWaitForTimeout[5]		= false;
	stateTransitionOnTriggerUp[5]  = "Fire2";
	stateAllowImageChange[5]        = false;

	stateName[6]                    = "Fire2";
	stateSequence[6]                = "Fire2";
	stateTransitionOnTimeout[6]     = "Ready3";
	stateTimeoutValue[6]            = 0.35;
	stateFire[6]                    = true;
	stateAllowImageChange[6]        = false;
	stateScript[6]                  = "onFireFast";
	stateWaitForTimeout[6]		= true;

//The Third strike.

	stateName[7]                     = "Ready3";
	stateSequence[7]                     = "Ready3";
	stateTransitionOnTriggerDown[7]  = "Fire3Pre";
	stateAllowImageChange[7]         = true;

	stateName[8]                    = "Fire3Pre";
	stateSequence[8]                = "Ready3";
	stateTimeoutValue[8]            = 0.7;
	stateTransitionOnTimeout[8]     = "Fire5Pre";
	stateWaitForTimeout[8]		= false;
	stateTransitionOnTriggerUp[8]  = "Fire3";
	stateAllowImageChange[8]        = false;

	stateName[9]                    = "Fire3";
	stateSequence[9]                = "Fire3";
	stateTransitionOnTimeout[9]     = "Ready4";
	stateTimeoutValue[9]            = 0.35;
	stateFire[9]                    = true;
	stateAllowImageChange[9]        = false;
	stateScript[9]                  = "onFireFast";
	stateWaitForTimeout[9]		= true;

//The Fourth Strike

	stateName[10]                     = "Ready4";
	stateSequence[10]                     = "Ready4";
	stateTransitionOnTriggerDown[10]  = "Fire4Pre";
	stateAllowImageChange[10]         = true;

	stateName[11]                    = "Fire4Pre";
	stateSequence[11]                = "Ready4";
	stateTimeoutValue[11]            = 0.7;
	stateTransitionOnTimeout[11]     = "Fire5Pre";
	stateWaitForTimeout[11]		= false;
	stateTransitionOnTriggerUp[11]  = "Fire4";
	stateAllowImageChange[11]        = false;

	stateName[12]                    = "Fire4";
	stateSequence[12]                = "Fire4";
	stateTransitionOnTimeout[12]     = "Ready1";
	stateTimeoutValue[12]            = 0.35;
	stateFire[12]                    = true;
	stateAllowImageChange[12]        = false;
	stateScript[12]                  = "onFireFast";
	stateWaitForTimeout[12]		= true;

//The Fifth (non sequencial) Strike

	stateName[13]                    = "Fire5Pre";
	stateSequence[13]                = "Ready1";
	stateTransitionOnTriggerUp[13]  = "Fire5_Swing";
	stateScript[13]                  = "onCharged";
	stateAllowImageChange[13]        = false;

	stateName[14]                    = "Fire5_Swing";
	stateSequence[14]                = "Fire5_1";
	stateTransitionOnTimeout[14]     = "Fire5_Hit";
	stateTimeoutValue[14]            = 0.35;
	stateAllowImageChange[14]        = false;
	stateScript[14]                  = "onSwing";
	stateWaitForTimeout[14]		= true;

	stateName[15]                    = "Fire5_Hit";
	stateSequence[15]                = "Fire5_2";
	stateTransitionOnTimeout[15]     = "Ready1";
	stateTimeoutValue[15]            = 0.55;
	stateFire[15]                    = true;
	stateAllowImageChange[15]        = false;
	stateScript[15]                  = "onFireMedium";
	stateWaitForTimeout[15]		= true;

};

function DCrossSpearImage::onFireFast(%this, %obj, %slot)
{
	
	%projectile = DCrossSpearFastProjectile;
	%spread = 0.00008;
	%shellcount = 1;

	%obj.playThread(3, plant);
                serverPlay3D(WooshFasterSound,%obj.getPosition());

	for(%shell=0; %shell<%shellcount; %shell++)
	{
		%vector = %obj.getMuzzleVector(%slot);
		%objectVelocity = %obj.getVelocity();
		%vector1 = VectorScale(%vector, %projectile.muzzleVelocity);
		%vector2 = VectorScale(%objectVelocity, %projectile.velInheritFactor);
		%velocity = VectorAdd(%vector1,%vector2);
		%x = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%y = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%z = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%mat = MatrixCreateFromEuler(%x @ " " @ %y @ " " @ %z);
		%velocity = MatrixMulVector(%mat, %velocity);

		%p = new (%this.projectileType)()
		{
			dataBlock = %projectile;
			initialVelocity = %velocity;
			initialPosition = %obj.getMuzzlePoint(%slot);
			sourceObject = %obj;
			sourceSlot = %slot;
			client = %obj.client;
		};
		MissionCleanup.add(%p);
	}
	return %p;
}

function DCrossSpearImage::onFireMedium(%this, %obj, %slot)
{
	
	%projectile = DCrossSpearMediumProjectile;
	%spread = 0.00008;
	%shellcount = 1;

	for(%shell=0; %shell<%shellcount; %shell++)
	{
		%vector = %obj.getMuzzleVector(%slot);
		%objectVelocity = %obj.getVelocity();
		%vector1 = VectorScale(%vector, %projectile.muzzleVelocity);
		%vector2 = VectorScale(%objectVelocity, %projectile.velInheritFactor);
		%velocity = VectorAdd(%vector1,%vector2);
		%x = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%y = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%z = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%mat = MatrixCreateFromEuler(%x @ " " @ %y @ " " @ %z);
		%velocity = MatrixMulVector(%mat, %velocity);

		%p = new (%this.projectileType)()
		{
			dataBlock = %projectile;
			initialVelocity = %velocity;
			initialPosition = %obj.getMuzzlePoint(%slot);
			sourceObject = %obj;
			sourceSlot = %slot;
			client = %obj.client;
		};
		MissionCleanup.add(%p);
	}
	return %p;
}

function DCrossSpearImage::onCharged(%this, %obj, %slot)
{	
		%obj.playThread(2, plant);
        serverPlay3D(DuelChargedSound,%obj.getPosition());

}

function DCrossSpearImage::onSwing(%this, %obj, %slot)
{	
		%obj.playThread(2, plant);
        serverPlay3D(WooshFasterSound,%obj.getPosition());

}


function DCrossSpearImage::onMount(%this, %obj, %slot)
{	

			%obj.hideNode("LHand");
			%obj.hideNode("RHand");
			%obj.hideNode("LHook");
			%obj.hideNode("RHook");
		%obj.playThread(0, armreadyboth);
}

function DCrossSpearImage::onUnMount(%this, %obj, %slot)
{	

			%obj.unhideNode("LHand");
			%obj.unhideNode("RHand");
		%obj.playThread(0, root);
}