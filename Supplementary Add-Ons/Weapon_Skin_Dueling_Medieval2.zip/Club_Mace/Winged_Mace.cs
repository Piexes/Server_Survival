datablock ProjectileData(DWingedMaceFastProjectile)
{
   directDamage        = 30;
   directDamageType  = $DamageType::Duel_Strike;
   radiusDamageType  = $DamageType::Duel_Strike;
   stickExplosion        = BluntMediumMetalExplosion;
   bloodExplosion        = BluntMetalPlayerHitExplosion;
   explosion           = BluntMediumMetalExplosion;

   muzzleVelocity      = 65;
   velInheritFactor    = 1;
   explodeOnPlayerImpact = true;
   explodeOnDeath        = false;  

   armingDelay         = 80;
   lifetime            = 80;
   fadeDelay           = 80;
   isBallistic         = true;
   bounceAngle         = 170; //stick almost all the time
   minStickVelocity    = 10;
   bounceElasticity    = 0.2;
   bounceFriction      = 0.01;   
   gravityMod = 0.0;

   hasLight    = false;
   lightRadius = 3.0;
   lightColor  = "0 0 0.5";
};

datablock ProjectileData(DWingedMaceStrongProjectile)
{
   directDamage        = 70;
   directDamageType  = $DamageType::Duel_Strike;
   radiusDamageType  = $DamageType::Duel_Strike;
   stickExplosion        = BluntMediumMetalExplosion;
   bloodExplosion        = BluntMetalPlayerHitExplosion;
   explosion           = BluntMediumMetalExplosion;

   muzzleVelocity      = 65;
   velInheritFactor    = 1;
   explodeOnPlayerImpact = true;
   explodeOnDeath        = false;  

   armingDelay         = 80;
   lifetime            = 80;
   fadeDelay           = 80;
   isBallistic         = true;
   bounceAngle         = 170; //stick almost all the time
   minStickVelocity    = 10;
   bounceElasticity    = 0.2;
   bounceFriction      = 0.01;   
   gravityMod = 0.0;

   hasLight    = false;
   lightRadius = 3.0;
   lightColor  = "0 0 0.5";
};


//////////
// item //
//////////
datablock ItemData(DWingedMaceItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./Winged_Mace_Item.dts";
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "Duel_M_Winged Mace";
	iconName = "./Winged_Mace_Icon";
	doColorShift = true;
	colorShiftColor = "0.471 0.471 0.471 1.000";

	 // Dynamic properties defined by the scripts
	image = DWingedMaceImage;
	canDrop = true;
};

////////////////
//weapon image//
////////////////
datablock ShapeBaseImageData(DWingedMaceImage)
{
   // Basic Item properties
   shapeFile = "./Winged_Mace.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = "-0.58 -0.75 -0.285"; //X Z Y


   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = false;

   eyeOffset = 0; //"0.7 1.2 -0.1";

   // Add the WeaponImage namespace as a parent, WeaponImage namespace
   // provides some hooks into the inventory system.
   className = "WeaponImage";

   // Projectile && Ammo.
   item = DWingedMaceItem;
   ammo = " ";
   projectile = DWingedMaceFastProjectile;
   projectileType = Projectile;

   //melee particles shoot from eye node for consistancy
   melee = true;
   doRetraction = false;
   //raise your arm up or not
   armReady = true;

   //casing = " ";
   doColorShift = true;
   colorShiftColor = "0.471 0.471 0.471 1.000";

   // Draw the Sword. The blade is the output of your true strength, even if only an extension.
//The first slice. If Lmouse is clicked and released; a fast attack will be performed.
//If the lmouse is held, upon charging fully for the first time (with no release until click is heard) a medium attack will be performed. Releasing pre-maturely will fire a fast attack.
//If the lmouse is held through the medium state; it will continue to charge up to the strong state. If released pre-maturely: a medium attack will be fired. 
	stateName[0]                     = "Activate";
	stateSequence[0]                     = "Activate";
	stateTimeoutValue[0]             = 2.0;
	stateTransitionOnTimeout[0]      = "Ready1";
	stateSound[0]                    = ClubDrawSound;

	stateName[1]                     = "Ready1";
	stateSequence[1]                     = "Ready1";
	stateTransitionOnTriggerDown[1]  = "Fire1Pre";
	stateAllowImageChange[1]         = true;

	stateName[2]                    = "Fire1Pre";
	stateSequence[2]                = "Ready1";
	stateTimeoutValue[2]            = 1.4;
	stateTransitionOnTimeout[2]     = "Fire4Pre";
	stateWaitForTimeout[2]		= false;
	stateTransitionOnTriggerUp[2]  = "Fire1";
	stateAllowImageChange[2]        = false;

	stateName[7]                    = "Fire1";
	stateSequence[7]                = "Fire1";
	stateTransitionOnTimeout[7]     = "Ready2";
	stateTimeoutValue[7]            = 0.35;
	stateFire[7]                    = true;
	stateAllowImageChange[7]        = false;
	stateScript[7]                  = "onFireFast";
	stateWaitForTimeout[7]		= true;

//The second Swing.

	stateName[8]                     = "Ready2";
	stateSequence[8]                     = "Ready2";
	stateTransitionOnTriggerDown[8]  = "Fire2Pre";
	stateAllowImageChange[8]         = true;

	stateName[9]                    = "Fire2Pre";
	stateSequence[9]                = "Ready2";
	stateTimeoutValue[9]            = 1.4;
	stateTransitionOnTimeout[9]     = "Fire4Pre";
	stateWaitForTimeout[9]		= false;
	stateTransitionOnTriggerUp[9]  = "Fire2";
	stateAllowImageChange[9]        = false;

	stateName[14]                    = "Fire2";
	stateSequence[14]                = "Fire2";
	stateTransitionOnTimeout[14]     = "Ready3";
	stateTimeoutValue[14]            = 0.35;
	stateFire[14]                    = true;
	stateAllowImageChange[14]        = false;
	stateScript[14]                  = "onFireFast";
	stateWaitForTimeout[14]		= true;

//The third Swing.

	stateName[15]                     = "Ready3";
	stateSequence[15]                     = "Ready3";
	stateTransitionOnTriggerDown[15]  = "Fire3Pre";
	stateAllowImageChange[15]         = true;

	stateName[16]                    = "Fire3Pre";
	stateSequence[16]                = "Ready3";
	stateTimeoutValue[16]            = 1.4;
	stateTransitionOnTimeout[16]     = "Fire4Pre";
	stateWaitForTimeout[16]		= false;
	stateTransitionOnTriggerUp[16]  = "Fire3";
	stateAllowImageChange[16]        = false;

	stateName[22]                    = "Fire3";
	stateSequence[22]                = "Fire3";
	stateTransitionOnTimeout[22]     = "Ready1";
	stateTimeoutValue[22]            = 0.35;
	stateFire[22]                    = true;
	stateAllowImageChange[22]        = false;
	stateScript[22]                  = "onFireFast";
	stateWaitForTimeout[22]		= true;

//Fourth (Non-Sequencial) Swing
	stateName[23]                    = "Fire4Pre";
	stateSequence[23]                = "Ready4";
	stateTransitionOnTriggerUp[23]  = "Fire4Swing";
	stateScript[23]                  = "onCharged";
	stateAllowImageChange[23]        = false;

	stateName[24]                    = "Fire4Swing";
	stateSequence[24]                = "Fire4_1";
	stateTransitionOnTimeout[24]     = "Fire4Hit";
	stateTimeoutValue[24]            = 0.30;
	stateAllowImageChange[24]        = false;
	stateScript[24]                  = "onSwing";
	stateWaitForTimeout[24]		= true;

	stateName[25]                    = "Fire4Hit";
	stateSequence[25]                = "Fire4_2";
	stateTransitionOnTimeout[25]     = "Ready1";
	stateTimeoutValue[25]            = 1.15;
	stateFire[25]                    = true;
	stateAllowImageChange[25]        = false;
	stateScript[25]                  = "onFireStrong";
	stateWaitForTimeout[25]		= true;

};

function DWingedMaceImage::onFireFast(%this, %obj, %slot)
{
	
	%projectile = DWingedMaceFastProjectile;
	%spread = 0.00008;
	%shellcount = 1;

	%obj.playThread(3, plant);
                serverPlay3D(WooshSound,%obj.getPosition());

	for(%shell=0; %shell<%shellcount; %shell++)
	{
		%vector = %obj.getMuzzleVector(%slot);
		%objectVelocity = %obj.getVelocity();
		%vector1 = VectorScale(%vector, %projectile.muzzleVelocity);
		%vector2 = VectorScale(%objectVelocity, %projectile.velInheritFactor);
		%velocity = VectorAdd(%vector1,%vector2);
		%x = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%y = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%z = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%mat = MatrixCreateFromEuler(%x @ " " @ %y @ " " @ %z);
		%velocity = MatrixMulVector(%mat, %velocity);

		%p = new (%this.projectileType)()
		{
			dataBlock = %projectile;
			initialVelocity = %velocity;
			initialPosition = %obj.getMuzzlePoint(%slot);
			sourceObject = %obj;
			sourceSlot = %slot;
			client = %obj.client;
		};
		MissionCleanup.add(%p);
	}
	return %p;
}

function DWingedMaceImage::onFireStrong(%this, %obj, %slot)
{
	
	%projectile = DWingedMaceStrongProjectile;
	%spread = 0.00008;
	%shellcount = 1;

	for(%shell=0; %shell<%shellcount; %shell++)
	{
		%vector = %obj.getMuzzleVector(%slot);
		%objectVelocity = %obj.getVelocity();
		%vector1 = VectorScale(%vector, %projectile.muzzleVelocity);
		%vector2 = VectorScale(%objectVelocity, %projectile.velInheritFactor);
		%velocity = VectorAdd(%vector1,%vector2);
		%x = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%y = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%z = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%mat = MatrixCreateFromEuler(%x @ " " @ %y @ " " @ %z);
		%velocity = MatrixMulVector(%mat, %velocity);

		%p = new (%this.projectileType)()
		{
			dataBlock = %projectile;
			initialVelocity = %velocity;
			initialPosition = %obj.getMuzzlePoint(%slot);
			sourceObject = %obj;
			sourceSlot = %slot;
			client = %obj.client;
		};
		MissionCleanup.add(%p);
	}
	return %p;
}

function DWingedMaceImage::onCharged(%this, %obj, %slot)
{	
		%obj.playThread(2, plant);
        serverPlay3D(DuelChargedSound,%obj.getPosition());

}

function DWingedMaceImage::onSwing(%this, %obj, %slot)
{	
		%obj.playThread(2, plant);
        serverPlay3D(WooshSound,%obj.getPosition());

}

function DWingedMaceImage::onMount(%this, %obj, %slot)
{	

			%obj.hideNode("LHand");
			%obj.hideNode("RHand");
			%obj.hideNode("LHook");
			%obj.hideNode("RHook");
		%obj.playThread(0, armreadyboth);
}

function DWingedMaceImage::onUnMount(%this, %obj, %slot)
{	

			%obj.unhideNode("LHand");
			%obj.unhideNode("RHand");
		%obj.playThread(0, root);
}

function DWingedMaceStrongProjectile::damage(%this,%obj,%col,%fade,%pos,%normal)
{
   if(%this.directDamage <= 0)
      return;

   %damageType = $DamageType::Direct;
   if(%this.DirectDamageType)
      %damageType = %this.DirectDamageType;

   %scale = getWord(%obj.getScale(), 2);
   %directDamage = %this.directDamage * 2;

   if(%col.getType() & $TypeMasks::PlayerObjectType)
   {
      %col.damage(%obj, %pos, %directDamage, %damageType);
   }
   else
   {
      %col.damage(%obj, %pos, %directDamage, %damageType);
   }	
}