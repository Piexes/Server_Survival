datablock ProjectileData(DBattleHammerFastProjectile)
{
   directDamage        = 70;
   directDamageType  = $DamageType::Duel_Strike;
   radiusDamageType  = $DamageType::Duel_Strike;
   stickExplosion        = BluntMediumMetalExplosion;
   bloodExplosion        = BluntMetalPlayerHitExplosion;
   explosion           = BluntMediumMetalExplosion;

   muzzleVelocity      = 65;
   velInheritFactor    = 1;
   impactImpulse	     = 1000;
   verticalImpulse	  = 500;
   explodeOnPlayerImpact = true;
   explodeOnDeath        = false;  

   armingDelay         = 80;
   lifetime            = 80;
   fadeDelay           = 80;
   isBallistic         = true;
   bounceAngle         = 170; //stick almost all the time
   minStickVelocity    = 10;
   bounceElasticity    = 0.2;
   bounceFriction      = 0.01;   
   gravityMod = 0.0;

   hasLight    = false;
   lightRadius = 3.0;
   lightColor  = "0 0 0.5";
};

datablock ProjectileData(DBattleHammerStrongProjectile)
{
   directDamage        = 100;
   directDamageType  = $DamageType::Duel_Strike;
   radiusDamageType  = $DamageType::Duel_Strike;
   stickExplosion        = BluntMediumMetalExplosion;
   bloodExplosion        = BluntMetalPlayerHitExplosion;
   explosion           = BluntMediumMetalExplosion;

   muzzleVelocity      = 65;
   velInheritFactor    = 1;
   impactImpulse	     = 1000;
   verticalImpulse	  = 500;
   explodeOnPlayerImpact = true;
   explodeOnDeath        = false;  

   armingDelay         = 80;
   lifetime            = 80;
   fadeDelay           = 80;
   isBallistic         = true;
   bounceAngle         = 170; //stick almost all the time
   minStickVelocity    = 10;
   bounceElasticity    = 0.2;
   bounceFriction      = 0.01;   
   gravityMod = 0.0;


   hasLight    = false;
   lightRadius = 3.0;
   lightColor  = "0 0 0.5";
};


//////////
// item //
//////////
datablock ItemData(BattleHammerItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./Battle_Hammer_Item.dts";
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "Duel_M_BattleHammer";
	iconName = "./Battle_Hammer_Icon";
	doColorShift = true;
	colorShiftColor = "0.471 0.471 0.471 1.000";

	 // Dynamic properties defined by the scripts
	image = DBattleHammerImage;
	canDrop = true;
};

////////////////
//weapon image//
////////////////
datablock ShapeBaseImageData(DBattleHammerImage)
{
   // Basic Item properties
   shapeFile = "./Battle_Hammer.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = "-0.58 -0.75 -0.285"; //X Z Y


   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = false;

   eyeOffset = 0; //"0.7 1.2 -0.1";

   // Add the WeaponImage namespace as a parent, WeaponImage namespace
   // provides some hooks into the inventory system.
   className = "WeaponImage";

   // Projectile && Ammo.
   item = BattleHammerItem;
   ammo = " ";
   projectile = DBattleHammerFastProjectile;
   projectileType = Projectile;

   //melee particles shoot from eye node for consistancy
   melee = true;
   doRetraction = false;
   //raise your arm up or not
   armReady = true;

   //casing = " ";
   doColorShift = true;
   colorShiftColor = "0.471 0.471 0.471 1.000";

   // Draw the Sword. The blade is the output of your true strength, even if only an extension.
//The first slice. If Lmouse is clicked and released; a fast attack will be performed.
//If the lmouse is held, upon charging fully for the first time (with no release until click is heard) a medium attack will be performed. Releasing pre-maturely will fire a fast attack.
//If the lmouse is held through the medium state; it will continue to charge up to the strong state. If released pre-maturely: a medium attack will be fired. 
	stateName[0]                     = "Activate";
                stateSound[0]                    = HammerDrawSound;
	stateSequence[0]                     = "Activate";
	stateTimeoutValue[0]             = 2.0;
	stateTransitionOnTimeout[0]      = "Ready1";

	stateName[1]                     = "Ready1";
	stateSequence[1]                     = "Ready1";
	stateTransitionOnTriggerDown[1]  = "Fire1Pre";
	stateAllowImageChange[1]         = true;

	stateName[2]                    = "Fire1Pre";
	stateSequence[2]                = "Ready1";
	stateTimeoutValue[2]            = 2.0;
	stateTransitionOnTimeout[2]     = "Fire4Pre";
	stateWaitForTimeout[2]		= false;
	stateTransitionOnTriggerUp[2]  = "Fire1_Swing";
	stateAllowImageChange[2]        = false;

	stateName[3]                    = "Fire1_Swing";
	stateSequence[3]                = "Fire1_1";
	stateTransitionOnTimeout[3]     = "Fire1_Hit";
	stateTimeoutValue[3]            = 0.45;
	stateScript[3]                  = "onSwing";
	stateAllowImageChange[3]        = false;
	stateWaitForTimeout[3]		= true;

	stateName[4]                    = "Fire1_Hit";
	stateSequence[4]                = "Fire1_2";
	stateTransitionOnTimeout[4]     = "Ready2";
	stateTimeoutValue[4]            = 1.15;
	stateFire[4]                    = true;
	stateAllowImageChange[4]        = false;
	stateScript[4]                  = "onFireFast";
	stateWaitForTimeout[4]		= true;

//The second Swing.

	stateName[5]                     = "Ready2";
	stateSequence[5]                     = "Ready2";
	stateTransitionOnTriggerDown[5]  = "Fire2Pre";
	stateAllowImageChange[5]         = true;

	stateName[6]                    = "Fire2Pre";
	stateSequence[6]                = "Ready2";
	stateTimeoutValue[6]            = 2.0;
	stateTransitionOnTimeout[6]     = "Fire4Pre";
	stateWaitForTimeout[6]		= false;
	stateTransitionOnTriggerUp[6]  = "Fire2_Swing";
	stateAllowImageChange[6]        = false;

	stateName[7]                    = "Fire2_Swing";
	stateSequence[7]                = "Fire2_1";
	stateTransitionOnTimeout[7]     = "Fire2_Hit";
	stateTimeoutValue[7]            = 0.45;
	stateScript[7]                  = "onSwing";
	stateAllowImageChange[7]        = false;
	stateWaitForTimeout[7]		= true;

	stateName[8]                    = "Fire2_Hit";
	stateSequence[8]                = "Fire2_2";
	stateTransitionOnTimeout[8]     = "Ready3";
	stateTimeoutValue[8]            = 1.15;
	stateFire[8]                    = true;
	stateAllowImageChange[8]        = false;
	stateScript[8]                  = "onFireFast";
	stateWaitForTimeout[8]		= true;

//The Third Swing

	stateName[9]                     = "Ready3";
	stateSequence[9]                     = "Ready3";
	stateTransitionOnTriggerDown[9]  = "Fire3Pre";
	stateAllowImageChange[9]         = true;

	stateName[10]                    = "Fire3Pre";
	stateSequence[10]                = "Ready3";
	stateTimeoutValue[10]            = 2.0;
	stateTransitionOnTimeout[10]     = "Fire4Pre";
	stateWaitForTimeout[10]		= false;
	stateTransitionOnTriggerUp[10]  = "Fire3_Swing";
	stateAllowImageChange[10]        = false;

	stateName[11]                    = "Fire3_Swing";
	stateSequence[11]                = "Fire3_1";
	stateTransitionOnTimeout[11]     = "Fire3_Hit";
	stateTimeoutValue[11]            = 0.45;
	stateScript[11]                  = "onSwing";
	stateAllowImageChange[11]        = false;
	stateWaitForTimeout[11]		= true;

	stateName[12]                    = "Fire3_Hit";
	stateSequence[12]                = "Fire3_2";
	stateTransitionOnTimeout[12]     = "Ready1";
	stateTimeoutValue[12]            = 1.15;
	stateFire[12]                    = true;
	stateAllowImageChange[12]        = false;
	stateScript[12]                  = "onFireFast";
	stateWaitForTimeout[12]		= true;

//The Third (fake sequential) Swing

	stateName[13]                    = "Fire4Pre";
	stateSequence[13]                = "Ready3";
	stateTransitionOnTriggerUp[13]  = "Fire4_Swing";
	stateScript[13]                  = "onCharged";
	stateAllowImageChange[13]        = false;

	stateName[14]                    = "Fire4_Swing";
	stateSequence[14]                = "Fire3_1";
	stateTransitionOnTimeout[14]     = "Fire4_Hit";
	stateTimeoutValue[14]            = 0.5;
	stateScript[14]                  = "onSwing";
	stateAllowImageChange[14]        = false;
	stateWaitForTimeout[14]		= true;

	stateName[15]                    = "Fire4_Hit";
	stateSequence[15]                = "Fire3_2";
	stateTransitionOnTimeout[15]     = "Ready1";
	stateTimeoutValue[15]            = 1.4;
	stateFire[15]                    = true;
	stateAllowImageChange[15]        = false;
	stateScript[15]                  = "onFireStrong";
	stateWaitForTimeout[15]		= true;
};


function DBattleHammerImage::onFireFast(%this, %obj, %slot)
{
	
	%projectile = DBattleHammerFastProjectile;
	%spread = 0.00008;
	%shellcount = 1;

	for(%shell=0; %shell<%shellcount; %shell++)
	{
		%vector = %obj.getMuzzleVector(%slot);
		%objectVelocity = %obj.getVelocity();
		%vector1 = VectorScale(%vector, %projectile.muzzleVelocity);
		%vector2 = VectorScale(%objectVelocity, %projectile.velInheritFactor);
		%velocity = VectorAdd(%vector1,%vector2);
		%x = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%y = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%z = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%mat = MatrixCreateFromEuler(%x @ " " @ %y @ " " @ %z);
		%velocity = MatrixMulVector(%mat, %velocity);

		%p = new (%this.projectileType)()
		{
			dataBlock = %projectile;
			initialVelocity = %velocity;
			initialPosition = %obj.getMuzzlePoint(%slot);
			sourceObject = %obj;
			sourceSlot = %slot;
			client = %obj.client;
		};
		MissionCleanup.add(%p);
	}
	return %p;
}

function DBattleHammerImage::onFireStrong(%this, %obj, %slot)
{
	
	%projectile = DBattleHammerStrongProjectile;
	%spread = 0.00008;
	%shellcount = 1;

	for(%shell=0; %shell<%shellcount; %shell++)
	{
		%vector = %obj.getMuzzleVector(%slot);
		%objectVelocity = %obj.getVelocity();
		%vector1 = VectorScale(%vector, %projectile.muzzleVelocity);
		%vector2 = VectorScale(%objectVelocity, %projectile.velInheritFactor);
		%velocity = VectorAdd(%vector1,%vector2);
		%x = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%y = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%z = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%mat = MatrixCreateFromEuler(%x @ " " @ %y @ " " @ %z);
		%velocity = MatrixMulVector(%mat, %velocity);

		%p = new (%this.projectileType)()
		{
			dataBlock = %projectile;
			initialVelocity = %velocity;
			initialPosition = %obj.getMuzzlePoint(%slot);
			sourceObject = %obj;
			sourceSlot = %slot;
			client = %obj.client;
		};
		MissionCleanup.add(%p);
	}
	return %p;
}

function DBattleHammerImage::onCharged(%this, %obj, %slot)
{	
		%obj.playThread(2, plant);
        serverPlay3D(DuelChargedSound,%obj.getPosition());

}

function DBattleHammerImage::onSwing(%this, %obj, %slot)
{	
		%obj.playThread(2, plant);
        serverPlay3D(WooshSound,%obj.getPosition());

}


function DBattleHammerImage::onMount(%this, %obj, %slot)
{	

			%obj.hideNode("LHand");
			%obj.hideNode("RHand");
			%obj.hideNode("LHook");
			%obj.hideNode("RHook");
		%obj.playThread(0, armreadyboth);
}

function DBattleHammerImage::onUnMount(%this, %obj, %slot)
{	

			%obj.unhideNode("LHand");
			%obj.unhideNode("RHand");
		%obj.playThread(0, root);
}

function DBattleHammerStrongProjectile::damage(%this,%obj,%col,%fade,%pos,%normal)
{
   if(%this.directDamage <= 0)
      return;

   %damageType = $DamageType::Direct;
   if(%this.DirectDamageType)
      %damageType = %this.DirectDamageType;

   %scale = getWord(%obj.getScale(), 2);
   %directDamage = %this.directDamage * 3;

   if(%col.getType() & $TypeMasks::PlayerObjectType)
   {
      %col.damage(%obj, %pos, %directDamage, %damageType);
   }
   else
   {
      %col.damage(%obj, %pos, %directDamage, %damageType);
   }	
}