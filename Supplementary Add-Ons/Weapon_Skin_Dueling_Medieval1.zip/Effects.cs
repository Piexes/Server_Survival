AddDamageType("Duel_Strike",   '<bitmap:add-ons/Weapon_Skin_Dueling_Medieval1/DuelStrikeCI> %1',    '%2 <bitmap:add-ons/Weapon_Skin_Dueling_Medieval1/DuelStrikeCI> %1',0.75,1);
//General ---------------------------------------------------------------------------------
datablock AudioProfile(DuelChargedSound)
{
   filename    = "./clickPlant.wav";
   description = AudioClosest3d;
   preload = true;
};

datablock AudioProfile(WooshFastestSound)
{
   filename    = "./Woosh Fastest.wav";
   description = AudioClosest3d;
   preload = true;
};

datablock AudioProfile(WooshFasterSound)
{
   filename    = "./Woosh Faster.wav";
   description = AudioClosest3d;
   preload = true;
};

datablock AudioProfile(WooshFastSound)
{
   filename    = "./Woosh Fast.wav";
   description = AudioClosest3d;
   preload = true;
};

datablock AudioProfile(WooshSound)
{
   filename    = "./Woosh.wav";
   description = AudioClosest3d;
   preload = true;
};

datablock AudioProfile(WooshSlowSound)
{
   filename    = "./Woosh Slow.wav";
   description = AudioClosest3d;
   preload = true;
};

datablock AudioProfile(WooshSlowestSound)
{
   filename    = "./Woosh Slowest.wav";
   description = AudioClosest3d;
   preload = true;
};


//Swords ---------------------------------------------------------------------------------
datablock AudioProfile(Duel_SwordDrawSound)
{
   filename    = "./swordDraw.wav";
   description = AudioClosest3d;
   preload = true;
};

datablock AudioProfile(Duel_SwordDrawFasterSound)
{
   filename    = "./swordDraw_Faster.wav";
   description = AudioClosest3d;
   preload = true;
};

datablock AudioProfile(Duel_SwordDrawSlowerSound)
{
   filename    = "./swordDraw_Slower.wav";
   description = AudioClosest3d;
   preload = true;
};

datablock AudioProfile(BladeHit1Sound)
{
   filename    = "./Sword_Hit 1.wav";
   description = AudioClosest3d;
   preload = true;
};

datablock AudioProfile(BladeHit2Sound)
{
   filename    = "./Sword_Hit 2.wav";
   description = AudioClosest3d;
   preload = true;
};

datablock AudioProfile(BladeHit3Sound)
{
   filename    = "./Sword_Hit 3.wav";
   description = AudioClosest3d;
   preload = true;
};

datablock AudioProfile(BladeHitPlayerSound)
{
   filename    = "./Sword_Hit Player.wav";
   description = AudioClosest3d;
   preload = true;
};


//Fists ---------------------------------------------------------------------------------
datablock AudioProfile(FistsHitHardSound)
{
   filename    = "./Punch 2.wav";
   description = AudioClosest3d;
   preload = true;
};


//Ranged ---------------------------------------------------------------------------------

datablock AudioProfile(DThrowingKnifeHitSound)
{
   filename    = "./Knife_Hit.wav";
   description = AudioClosest3d;
   preload = true;
};

datablock AudioProfile(ThrowingKnifeThrowSound)
{
   filename    = "./Knife_Throw.wav";
   description = AudioClosest3d;
   preload = true;
};


datablock ParticleData(BluntMetalExplosionSparkParticle)
{
   dragCoefficient      = 0.5;
   gravityCoefficient   = 1.0;
   inheritedVelFactor   = 0.5;
   constantAcceleration = 0.0;
   lifetimeMS           = 400;
   lifetimeVarianceMS   = 250;
   textureName          = "base/data/particles/star1";

	spinSpeed		= 50.0;
	spinRandomMin		= -500.0;
	spinRandomMax		= 500.0;

   colors[0]     = "1.0 1.0 0.0 1.0";
   colors[1]     = "1.0 1.0 0.0 0.0";
   sizes[0]      = 0.15;
   sizes[1]      = 0.15;

   useInvAlpha = false;
};

datablock ParticleEmitterData(BluntMetalExplosionSparkEmitter)
{
	lifeTimeMS = 50;

   ejectionPeriodMS = 3;
   periodVarianceMS = 0;
   ejectionVelocity = 6;
   velocityVariance = 1.0;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 95;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = BluntMetalExplosionSparkParticle;

   uiName = "Blunt Metal Dust";
   emitterNode = HalfEmitterNode;
};


datablock ExplosionData(BladeSmallMetalExplosion)
{
   //explosionShape = "";
	soundProfile = BladeHit2Sound;

   lifeTimeMS = 150;

   particleEmitter = BluntMetalExplosionSparkEmitter;
   particleDensity = 4;
   particleRadius = 0.25;

   faceViewer     = true;
   explosionScale = "1 1 1";

   shakeCamera = true;
   camShakeFreq = "20.0 22.0 20.0";
   camShakeAmp = "1.0 1.0 1.0";
   camShakeDuration = 0.35;
   camShakeRadius = 8.5;

   // Dynamic light
   lightStartRadius = 3;
   lightEndRadius = 0.0;
   lightStartColor = "0.4 0.4 0.0 0.6";
   lightEndColor = "0 0 0";
};

datablock ExplosionData(BladeMediumMetalExplosion)
{
   //explosionShape = "";
	soundProfile = BladeHit1Sound;

   lifeTimeMS = 150;

   particleEmitter = BluntMetalExplosionSparkEmitter;
   particleDensity = 5;
   particleRadius = 0.25;

   faceViewer     = true;
   explosionScale = "1 1 1";

   shakeCamera = true;
   camShakeFreq = "20.0 22.0 20.0";
   camShakeAmp = "1.0 1.0 1.0";
   camShakeDuration = 0.35;
   camShakeRadius = 8.5;

   // Dynamic light
   lightStartRadius = 3;
   lightEndRadius = 0.0;
   lightStartColor = "0.4 0.4 0.0 0.6";
   lightEndColor = "0 0 0";
};

datablock ExplosionData(BladeLargeMetalExplosion)
{
   //explosionShape = "";
	soundProfile = BladeHit3Sound;

   lifeTimeMS = 150;

   particleEmitter = BluntMetalExplosionSparkEmitter;
   particleDensity = 6;
   particleRadius = 0.25;

   faceViewer     = true;
   explosionScale = "1 1 1";

   shakeCamera = true;
   camShakeFreq = "20.0 22.0 20.0";
   camShakeAmp = "1.0 1.0 1.0";
   camShakeDuration = 0.35;
   camShakeRadius = 8.5;

   // Dynamic light
   lightStartRadius = 3;
   lightEndRadius = 0.0;
   lightStartColor = "0.4 0.4 0.0 0.6";
   lightEndColor = "0 0 0";
};

datablock ParticleData(BladeMetalPlayerHitExplosionParticle)
{
   dragCoefficient      = 2;
   gravityCoefficient   = 1.0;
   inheritedVelFactor   = 0.35;
   constantAcceleration = 0.0;
   spinRandomMin = -90;
   spinRandomMax = 90;
   lifetimeMS           = 300;
   lifetimeVarianceMS   = 250;
   textureName          = "base/data/particles/chunk";
   colors[0]     = "0.9 0.9 0.6 0.9";
   colors[1]     = "0.9 0.9 0.9 0.0";
   sizes[0]      = 0.35;
   sizes[1]      = 0.35;
};

datablock ParticleEmitterData(BladeMetalPlayerHitExplosionEmitter)
{
   ejectionPeriodMS = 3;
   periodVarianceMS = 0;
   ejectionVelocity = 6.5;
   velocityVariance = 1.0;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 95;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "BladeMetalPlayerHitExplosionParticle";
};

datablock ExplosionData(BladeMetalPlayerHitExplosion)
{
   //explosionShape = "";
	soundProfile = BladeHitPlayerSound;

   lifeTimeMS = 150;

   particleEmitter = BladeMetalPlayerHitExplosionEmitter;
   particleDensity = 4;
   particleRadius = 0.15;

   faceViewer     = true;
   explosionScale = "1 1 1";

   shakeCamera = true;
   camShakeFreq = "20.0 22.0 20.0";
   camShakeAmp = "1.0 1.0 1.0";
   camShakeDuration = 0.35;
   camShakeRadius = 8.5;

   // Dynamic light
   lightStartRadius = 0;
   lightEndRadius = 0.0;
   lightStartColor = "0.4 0.4 0.0 0.6";
   lightEndColor = "0 0 0";
};


datablock ExplosionData(ThrowingKnifesStickExplosion)
{
   //explosionShape = "";
	soundProfile = ThrowingKnifeHitSound;

   lifeTimeMS = 150;

//   particleEmitter = arrowStickExplosionEmitter;
//   particleDensity = 10;
//   particleRadius = 0.2;

   emitter[0] = "";

   faceViewer     = true;
   explosionScale = "1 1 1";

   shakeCamera = false;
   camShakeFreq = "10.0 11.0 10.0";
   camShakeAmp = "1.0 1.0 1.0";
   camShakeDuration = 0.5;
   camShakeRadius = 10.0;

   // Dynamic light
   lightStartRadius = 0;
   lightEndRadius = 0.0;
   lightStartColor = "0.4 0.4 0.0 0.6";
   lightEndColor = "0 0 0";
};

datablock ExplosionData(ThrowingKnifesExplosion)
{
   //explosionShape = "";
   lifeTimeMS = 350;

//	soundProfile = DThrowingKnifeHitSound;

//   particleEmitter = ;
//   particleDensity = 4;
//   particleRadius = 0.1;

   faceViewer     = true;
   explosionScale = "1 1 1";

   shakeCamera = false;
   camShakeFreq = "20.0 22.0 20.0";
   camShakeAmp = "1.0 1.0 1.0";
   camShakeDuration = 0.35;
   camShakeRadius = 8.5;

   // Dynamic light
   lightStartRadius = 0;
   lightEndRadius = 0.0;
   lightStartColor = "0.4 0.4 0.0 0.6";
   lightEndColor = "0 0 0";
};


datablock ParticleData(FistsExplosionParticle)
{
   dragCoefficient      = 10;
   gravityCoefficient   = -0.15;
   inheritedVelFactor   = 0.2;
   constantAcceleration = 0.0;
   lifetimeMS           = 800;
   lifetimeVarianceMS   = 500;
   textureName          = "base/data/particles/cloud";

	spinSpeed		= 50.0;
	spinRandomMin		= -500.0;
	spinRandomMax		= 500.0;

   colors[0]     = "1.0 1.0 1.0 0.25";
   colors[1]     = "0.0 0.0 0.0 0.0";
   sizes[0]      = 0.35;
   sizes[1]      = 0.5;

   useInvAlpha = true;
};

datablock ParticleEmitterData(FistsExplosionEmitter)
{
	lifeTimeMS = 50;

   ejectionPeriodMS = 3;
   periodVarianceMS = 0;
   ejectionVelocity = 10;
   velocityVariance = 1.0;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 95;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = FistsExplosionParticle;

   uiName = "DFist Hit";
   emitterNode = HalfEmitterNode;
};

datablock ExplosionData(FistsHardExplosion)
{
   //explosionShape = "";
   lifeTimeMS = 350;

   soundProfile = FistsHitHardSound;

   particleEmitter = FistsExplosionEmitter;
   particleDensity = 10;
   particleRadius = 0.15;

   faceViewer     = true;
   explosionScale = "1 1 1";

   shakeCamera = true;
   camShakeFreq = "20.0 22.0 20.0";
   camShakeAmp = "1.0 1.0 1.0";
   camShakeDuration = 0.35;
   camShakeRadius = 8.5;

   // Dynamic light
   lightStartRadius = 0;
   lightEndRadius = 0.0;
   lightStartColor = "0.4 0.4 0.0 0.6";
   lightEndColor = "0 0 0";
};