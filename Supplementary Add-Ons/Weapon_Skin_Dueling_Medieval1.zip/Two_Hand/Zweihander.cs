datablock ProjectileData(DZweihanderFastProjectile)
{
   directDamage        = 20;
   directDamageType  = $DamageType::Duel_Strike;
   radiusDamageType  = $DamageType::Duel_Strike;
   stickExplosion        = BladeLargeMetalExplosion;
   bloodExplosion        = BladeMetalPlayerHitExplosion;
   explosion           = BladeLargeMetalExplosion;

   muzzleVelocity      = 65;
   velInheritFactor    = 1;
   explodeOnPlayerImpact = true;
   explodeOnDeath        = false;  

   armingDelay         = 80;
   lifetime            = 80;
   fadeDelay           = 80;
   isBallistic         = true;
   bounceAngle         = 170; //stick almost all the time
   minStickVelocity    = 10;
   bounceElasticity    = 0.2;
   bounceFriction      = 0.01;   
   gravityMod = 0.0;

   hasLight    = false;
   lightRadius = 3.0;
   lightColor  = "0 0 0.5";
};

datablock ProjectileData(DZweihanderStrongProjectile)
{
   directDamage        = 75;
   directDamageType  = $DamageType::Duel_Strike;
   radiusDamageType  = $DamageType::Duel_Strike;
   stickExplosion        = BladeLargeMetalExplosion;
   bloodExplosion        = BladeMetalPlayerHitExplosion;
   explosion           = BladeLargeMetalExplosion;

   muzzleVelocity      = 65;
   velInheritFactor    = 1;
   explodeOnPlayerImpact = true;
   explodeOnDeath        = false;  

   armingDelay         = 80;
   lifetime            = 80;
   fadeDelay           = 80;
   isBallistic         = true;
   bounceAngle         = 170; //stick almost all the time
   minStickVelocity    = 10;
   bounceElasticity    = 0.2;
   bounceFriction      = 0.01;   
   gravityMod = 0.0;

   hasLight    = false;
   lightRadius = 3.0;
   lightColor  = "0 0 0.5";
};


//////////
// item //
//////////
datablock ItemData(DZweihanderItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./Zweihander_Item.dts";
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "Duel_M_Zweihander";
	iconName = "./Zweihander_Icon";
	doColorShift = true;
	colorShiftColor = "0.471 0.471 0.471 1.000";

	 // Dynamic properties defined by the scripts
	image = DZweihanderImage;
	canDrop = true;
};

////////////////
//weapon image//
////////////////
datablock ShapeBaseImageData(DZweihanderImage)
{
   // Basic Item properties
   shapeFile = "./Zweihander.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = "-0.58 -0.75 -0.285"; //X Z Y


   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = false;

   eyeOffset = 0; //"0.7 1.2 -0.1";

   // Add the WeaponImage namespace as a parent, WeaponImage namespace
   // provides some hooks into the inventory system.
   className = "WeaponImage";

   // Projectile && Ammo.
   item = DZweihanderELGItem;
   ammo = " ";
   projectile = DZweihanderFastProjectile;
   projectileType = Projectile;

   //melee particles shoot from eye node for consistancy
   melee = true;
   doRetraction = false;
   //raise your arm up or not
   armReady = true;

   //casing = " ";
   doColorShift = true;
   colorShiftColor = "0.471 0.471 0.471 1.000";

   // Draw the Sword. The blade is the output of your true strength, even if only an extension.
//The first slice. If Lmouse is clicked and released; a fast attack will be performed.
//If the lmouse is held, upon charging fully for the first time (with no release until click is heard) a medium attack will be performed. Releasing pre-maturely will fire a fast attack.
//If the lmouse is held through the medium state; it will continue to charge up to the strong state. If released pre-maturely: a medium attack will be fired. 
//The first Swing.

//The first Swing.

	stateName[0]                     = "Activate";
    stateSound[0]                    = Duel_SwordDrawSound;
	stateSequence[0]                     = "Activate";
	stateTimeoutValue[0]             = 2.0;
	stateTransitionOnTimeout[0]      = "Ready1";

	stateName[1]                     = "Ready1";
	stateSequence[1]                     = "Ready1";
	stateTransitionOnTriggerDown[1]  = "Fire1Pre";
	stateAllowImageChange[1]         = true;

	stateName[2]                    = "Fire1Pre";
	stateSequence[2]                = "Ready1";
	stateTimeoutValue[2]            = 1.4;
	stateTransitionOnTimeout[2]     = "Fire5Pre";
	stateWaitForTimeout[2]		= false;
	stateTransitionOnTriggerUp[2]  = "Fire1";
	stateAllowImageChange[2]        = false;

	stateName[8]                    = "Fire1";
	stateSequence[8]                = "Fire1";
	stateTransitionOnTimeout[8]     = "Ready2";
	stateTimeoutValue[8]            = 0.35;
	stateFire[8]                    = true;
	stateAllowImageChange[8]        = false;
	stateScript[8]                  = "onFireFast";
	stateWaitForTimeout[8]		= true;

//The second Swing.

	stateName[9]                     = "Ready2";
	stateSequence[9]                     = "Ready2";
	stateTransitionOnTriggerDown[9]  = "Fire2Pre";
	stateAllowImageChange[9]         = true;
	
	stateName[10]                    = "Fire2Pre";
	stateSequence[10]                = "Ready2";
	stateTimeoutValue[10]            = 1.4;
	stateTransitionOnTimeout[10]     = "Fire5Pre";
	stateWaitForTimeout[10]		= false;
	stateTransitionOnTriggerUp[10]  = "Fire2";
	stateAllowImageChange[10]        = false;

	stateName[12]                    = "Fire2";
	stateSequence[12]                = "Fire2";
	stateTransitionOnTimeout[12]     = "Ready3";
	stateTimeoutValue[12]            = 0.35;
	stateFire[12]                    = true;
	stateAllowImageChange[12]        = false;
	stateScript[12]                  = "onFireFast";
	stateWaitForTimeout[12]		= true;

//The Third Swing

	stateName[13]                     = "Ready3";
	stateSequence[13]                     = "Ready3";
	stateTransitionOnTriggerDown[13]  = "Fire3Pre";
	stateAllowImageChange[13]         = true;
	
	stateName[15]                    = "Fire3Pre";
	stateSequence[15]                = "Ready3";
	stateTimeoutValue[15]            = 1.4;
	stateTransitionOnTimeout[15]     = "Fire5Pre";
	stateWaitForTimeout[15]		= false;
	stateTransitionOnTriggerUp[15]  = "Fire3";
	stateAllowImageChange[15]        = false;

	stateName[16]                    = "Fire3";
	stateSequence[16]                = "Fire3";
	stateTransitionOnTimeout[16]     = "Ready4";
	stateTimeoutValue[16]            = 0.35;
	stateFire[16]                    = true;
	stateAllowImageChange[16]        = false;
	stateScript[16]                  = "onFireFast";
	stateWaitForTimeout[16]		= true;

//The fourth Swing.

	stateName[17]                     = "Ready4";
	stateSequence[17]                     = "Ready4";
	stateTransitionOnTriggerDown[17]  = "Fire4Pre";
	stateAllowImageChange[17]         = true;
	
	stateName[18]                    = "Fire4Pre";
	stateSequence[18]                = "Ready4";
	stateTimeoutValue[18]            = 1.4;
	stateTransitionOnTimeout[18]     = "Fire5Pre";
	stateWaitForTimeout[18]		= false;
	stateTransitionOnTriggerUp[18]  = "Fire4";
	stateAllowImageChange[18]        = false;

	stateName[24]                    = "Fire4";
	stateSequence[24]                = "Fire4";
	stateTransitionOnTimeout[24]     = "Ready1";
	stateTimeoutValue[24]            = 0.35;
	stateFire[24]                    = true;
	stateAllowImageChange[24]        = false;
	stateScript[24]                  = "onFireFast";
	stateWaitForTimeout[24]		= true;

//The Fifth (non sequencial) swing

	stateName[25]                    = "Fire5Pre";
	stateSequence[25]                = "Ready5";
	stateTransitionOnTriggerUp[25]  = "Fire5_Swing";
	stateScript[25]                  = "onCharged";
	stateAllowImageChange[25]        = false;

	stateName[26]                    = "Fire5_Swing";
	stateSequence[26]                = "Fire5_1";
	stateTransitionOnTimeout[26]     = "Fire5_Hit";
	stateTimeoutValue[26]            = 0.35;
	stateAllowImageChange[26]        = false;
	stateScript[26]                  = "onSwing";
	stateWaitForTimeout[26]		= true;

	stateName[27]                    = "Fire5_Hit";
	stateSequence[27]                = "Fire5_2";
	stateTransitionOnTimeout[27]     = "Ready1";
	stateTimeoutValue[27]            = 1.2;
	stateFire[27]                    = true;
	stateAllowImageChange[27]        = false;
	stateScript[27]                  = "onFireStrong";
	stateWaitForTimeout[27]		= true;

};

function DZweihanderImage::onFireFast(%this, %obj, %slot)
{
	
	%projectile = DZweihanderFastProjectile;
	%spread = 0.00008;
	%shellcount = 1;

	%obj.playThread(3, plant);
                serverPlay3D(WooshSound,%obj.getPosition());

	for(%shell=0; %shell<%shellcount; %shell++)
	{
		%vector = %obj.getMuzzleVector(%slot);
		%objectVelocity = %obj.getVelocity();
		%vector1 = VectorScale(%vector, %projectile.muzzleVelocity);
		%vector2 = VectorScale(%objectVelocity, %projectile.velInheritFactor);
		%velocity = VectorAdd(%vector1,%vector2);
		%x = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%y = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%z = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%mat = MatrixCreateFromEuler(%x @ " " @ %y @ " " @ %z);
		%velocity = MatrixMulVector(%mat, %velocity);

		%p = new (%this.projectileType)()
		{
			dataBlock = %projectile;
			initialVelocity = %velocity;
			initialPosition = %obj.getMuzzlePoint(%slot);
			sourceObject = %obj;
			sourceSlot = %slot;
			client = %obj.client;
		};
		MissionCleanup.add(%p);
	}
	return %p;
}

function DZweihanderImage::onFireStrong(%this, %obj, %slot)
{
	
	%projectile = DZweihanderStrongProjectile;
	%spread = 0.00008;
	%shellcount = 1;

	for(%shell=0; %shell<%shellcount; %shell++)
	{
		%vector = %obj.getMuzzleVector(%slot);
		%objectVelocity = %obj.getVelocity();
		%vector1 = VectorScale(%vector, %projectile.muzzleVelocity);
		%vector2 = VectorScale(%objectVelocity, %projectile.velInheritFactor);
		%velocity = VectorAdd(%vector1,%vector2);
		%x = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%y = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%z = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%mat = MatrixCreateFromEuler(%x @ " " @ %y @ " " @ %z);
		%velocity = MatrixMulVector(%mat, %velocity);

		%p = new (%this.projectileType)()
		{
			dataBlock = %projectile;
			initialVelocity = %velocity;
			initialPosition = %obj.getMuzzlePoint(%slot);
			sourceObject = %obj;
			sourceSlot = %slot;
			client = %obj.client;
		};
		MissionCleanup.add(%p);
	}
	return %p;
}

function DZweihanderImage::onCharged(%this, %obj, %slot)
{	
		%obj.playThread(2, plant);
        serverPlay3D(DuelChargedSound,%obj.getPosition());

}

function DZweihanderImage::onSwing(%this, %obj, %slot)
{	
		%obj.playThread(2, plant);
        serverPlay3D(WooshSound,%obj.getPosition());

}


function DZweihanderImage::onMount(%this, %obj, %slot)
{	

			%obj.hideNode("LHand");
			%obj.hideNode("RHand");
			%obj.hideNode("LHook");
			%obj.hideNode("RHook");
		%obj.playThread(0, armreadyboth);
}

function DZweihanderImage::onUnMount(%this, %obj, %slot)
{	

			%obj.unhideNode("LHand");
			%obj.unhideNode("RHand");
		%obj.playThread(0, root);
}

function DZweihanderStrongProjectile::damage(%this,%obj,%col,%fade,%pos,%normal)
{
   if(%this.directDamage <= 0)
      return;

   %damageType = $DamageType::Direct;
   if(%this.DirectDamageType)
      %damageType = %this.DirectDamageType;

   %scale = getWord(%obj.getScale(), 2);
   %directDamage = %this.directDamage * 2;

   if(%col.getType() & $TypeMasks::PlayerObjectType)
   {
      %col.damage(%obj, %pos, %directDamage, %damageType);
   }
   else
   {
      %col.damage(%obj, %pos, %directDamage, %damageType);
   }	
}