  exec("./Effects.cs");
  exec("./One_Hand/Falchion.cs");
  exec("./One_Hand/Gladius.cs");
  exec("./Dual_Sword/Dual_Falchions.cs");
  exec("./Heavy_Sword/Bastard.cs");
  exec("./Two_Hand/Long_Sword.cs");
  exec("./Two_Hand/Zweihander.cs");
