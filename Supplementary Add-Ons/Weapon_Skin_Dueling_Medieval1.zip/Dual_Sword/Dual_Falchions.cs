datablock ProjectileData(DDualFalchionsFastProjectile)
{
   directDamage        = 25;
   directDamageType  = $DamageType::Duel_Strike;
   radiusDamageType  = $DamageType::Duel_Strike;
   stickExplosion        = BladeSmallMetalExplosion;
   bloodExplosion        = BladeMetalPlayerHitExplosion;
   explosion           = BladeSmallMetalExplosion;

   muzzleVelocity      = 65;
   velInheritFactor    = 1;
   explodeOnPlayerImpact = true;
   explodeOnDeath        = false;  

   armingDelay         = 80;
   lifetime            = 80;
   fadeDelay           = 80;
   isBallistic         = true;
   bounceAngle         = 170; //stick almost all the time
   minStickVelocity    = 10;
   bounceElasticity    = 0.2;
   bounceFriction      = 0.01;   
   gravityMod = 0.0;

   hasLight    = false;
   lightRadius = 3.0;
   lightColor  = "0 0 0.5";
};

datablock ProjectileData(DDualFalchionsStrongProjectile)
{
   directDamage        = 75;
   directDamageType  = $DamageType::Duel_Strike;
   radiusDamageType  = $DamageType::Duel_Strike;
   stickExplosion        = BladeSmallMetalExplosion;
   bloodExplosion        = BladeMetalPlayerHitExplosion;
   explosion           = BladeSmallMetalExplosion;

   muzzleVelocity      = 65;
   velInheritFactor    = 1;
   explodeOnPlayerImpact = true;
   explodeOnDeath        = false;  

   armingDelay         = 80;
   lifetime            = 80;
   fadeDelay           = 80;
   isBallistic         = true;
   bounceAngle         = 170; //stick almost all the time
   minStickVelocity    = 10;
   bounceElasticity    = 0.2;
   bounceFriction      = 0.01;   
   gravityMod = 0.0;

   hasLight    = false;
   lightRadius = 3.0;
   lightColor  = "0 0 0.5";
};


//////////
// item //
//////////
datablock ItemData(DDualFalchionsItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./Dual_Falchions_Item.dts";
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "Duel_M_Dual_Falchions";
	iconName = "./Dual_Falchions_Icon";
	doColorShift = true;
	colorShiftColor = "0.471 0.471 0.471 1.000";

	 // Dynamic properties defined by the scripts
	image = DDualFalchionsImage;
	canDrop = true;
};

////////////////
//weapon image//
////////////////
datablock ShapeBaseImageData(DDualFalchionsImage)
{
   // Basic Item properties
   shapeFile = "./Dual_Falchions.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = "-0.58 -0.75 -0.285"; //X Z Y


   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = false;

   eyeOffset = 0; //"0.7 1.2 -0.1";

   // Add the WeaponImage namespace as a parent, WeaponImage namespace
   // provides some hooks into the inventory system.
   className = "WeaponImage";

   // Projectile && Ammo.
   item = DDualFalchionsItem;
   ammo = " ";
   projectile = DDualFalchionsFastProjectile;
   projectileType = Projectile;

   //melee particles shoot from eye node for consistancy
   melee = true;
   doRetraction = false;
   //raise your arm up or not
   armReady = true;

   //casing = " ";
   doColorShift = true;
   colorShiftColor = "0.471 0.471 0.471 1.000";

   // Draw the Sword. The blade is the output of your true strength, even if only an extension.
//The first slice. If Lmouse is clicked and released; a fast attack will be performed.
//If the lmouse is held, upon charging fully for the first time (with no release until click is heard) a medium attack will be performed. Releasing pre-maturely will fire a fast attack.
//If the lmouse is held through the medium state; it will continue to charge up to the strong state. If released pre-maturely: a medium attack will be fired. 
	stateName[0]                     = "Activate";
                stateSound[0]                    = Duel_SwordDrawSound;
	stateSequence[0]                     = "Activate";
	stateTimeoutValue[0]             = 2.0;
	stateTransitionOnTimeout[0]      = "Ready1";

	stateName[1]                     = "Ready1";
	stateSequence[1]                     = "Ready1";
	stateTransitionOnTriggerDown[1]  = "Fire1Pre";
	stateAllowImageChange[1]         = true;

	stateName[2]                    = "Fire1Pre";
	stateSequence[2]                = "Ready1";
	stateTimeoutValue[2]            = 0.75;
	stateTransitionOnTimeout[2]     = "Fire4Pre";
	stateWaitForTimeout[2]		= false;
	stateTransitionOnTriggerUp[2]  = "Fire1";
	stateAllowImageChange[2]        = false;

	stateName[3]                    = "Fire1";
	stateSequence[3]                = "Fire1";
	stateTransitionOnTimeout[3]     = "Ready2";
	stateTimeoutValue[3]            = 0.3;
	stateFire[3]                    = true;
	stateAllowImageChange[3]        = false;
	stateScript[3]                  = "onFireFast";
	stateWaitForTimeout[3]		= true;

//The second Swing.

	stateName[4]                     = "Ready2";
	stateSequence[4]                     = "Ready2";
	stateTransitionOnTriggerDown[4]  = "Fire2Pre";
	stateAllowImageChange[4]         = true;

	stateName[5]                    = "Fire2Pre";
	stateSequence[5]                = "Ready2";
	stateTimeoutValue[5]            = 0.75;
	stateTransitionOnTimeout[5]     = "Fire4Pre";
	stateWaitForTimeout[5]		= false;
	stateTransitionOnTriggerUp[5]  = "Fire2";
	stateAllowImageChange[5]        = false;

	stateName[6]                    = "Fire2";
	stateSequence[6]                = "Fire2";
	stateTransitionOnTimeout[6]     = "Ready3";
	stateTimeoutValue[6]            = 0.3;
	stateFire[6]                    = true;
	stateAllowImageChange[6]        = false;
	stateScript[6]                  = "onFireFast";
	stateWaitForTimeout[6]		= true;

//The Third Swing

	stateName[7]                     = "Ready3";
	stateSequence[7]                     = "Ready3";
	stateTransitionOnTriggerDown[7]  = "Fire3Pre";
	stateAllowImageChange[7]         = true;

	stateName[8]                    = "Fire3Pre";
	stateSequence[8]                = "Ready3";
	stateTimeoutValue[8]            = 0.75;
	stateTransitionOnTimeout[8]     = "Fire4Pre";
	stateWaitForTimeout[8]		= false;
	stateTransitionOnTriggerUp[8]  = "Fire3";
	stateAllowImageChange[8]        = false;

	stateName[9]                    = "Fire3";
	stateSequence[9]                = "Fire3";
	stateTransitionOnTimeout[9]     = "Ready1";
	stateTimeoutValue[9]            = 0.3;
	stateFire[9]                    = true;
	stateAllowImageChange[9]        = false;
	stateScript[9]                  = "onFireFast";
	stateWaitForTimeout[9]		= true;

//The Fourth (non sequencial) swing

	stateName[12]                    = "Fire4Pre";
	stateSequence[12]                = "Ready4";
	stateTransitionOnTriggerUp[12]  = "Fire4_Swing";
	stateScript[12]                  = "onCharged";
	stateAllowImageChange[12]        = false;

	stateName[13]                    = "Fire4_Swing";
	stateSequence[13]                = "Fire4_1";
	stateTransitionOnTimeout[13]     = "Fire4_Hit";
	stateTimeoutValue[13]            = 0.20;
	stateScript[13]                  = "onSwing";
	stateAllowImageChange[13]        = false;
	stateWaitForTimeout[13]		= true;

	stateName[14]                    = "Fire4_Hit";
	stateSequence[14]                = "Fire4_2";
	stateTransitionOnTimeout[14]     = "Ready1";
	stateTimeoutValue[14]            = 0.6;
	stateFire[14]                    = true;
	stateAllowImageChange[14]        = false;
	stateScript[14]                  = "onFireStrong";
	stateWaitForTimeout[14]		= true;

};

function DDualFalchionsImage::onFireFast(%this, %obj, %slot)
{
	
	%projectile = DDualFalchionsFastProjectile;
	%spread = 0.00008;
	%shellcount = 1;

	%obj.playThread(3, plant);
                serverPlay3D(WooshFastestSound,%obj.getPosition());

	for(%shell=0; %shell<%shellcount; %shell++)
	{
		%vector = %obj.getMuzzleVector(%slot);
		%objectVelocity = %obj.getVelocity();
		%vector1 = VectorScale(%vector, %projectile.muzzleVelocity);
		%vector2 = VectorScale(%objectVelocity, %projectile.velInheritFactor);
		%velocity = VectorAdd(%vector1,%vector2);
		%x = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%y = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%z = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%mat = MatrixCreateFromEuler(%x @ " " @ %y @ " " @ %z);
		%velocity = MatrixMulVector(%mat, %velocity);

		%p = new (%this.projectileType)()
		{
			dataBlock = %projectile;
			initialVelocity = %velocity;
			initialPosition = %obj.getMuzzlePoint(%slot);
			sourceObject = %obj;
			sourceSlot = %slot;
			client = %obj.client;
		};
		MissionCleanup.add(%p);
	}
	return %p;
}

function DDualFalchionsImage::onFireStrong(%this, %obj, %slot)
{
	
	%projectile = DDualFalchionsStrongProjectile;
	%spread = 0.00008;
	%shellcount = 1;

	for(%shell=0; %shell<%shellcount; %shell++)
	{
		%vector = %obj.getMuzzleVector(%slot);
		%objectVelocity = %obj.getVelocity();
		%vector1 = VectorScale(%vector, %projectile.muzzleVelocity);
		%vector2 = VectorScale(%objectVelocity, %projectile.velInheritFactor);
		%velocity = VectorAdd(%vector1,%vector2);
		%x = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%y = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%z = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%mat = MatrixCreateFromEuler(%x @ " " @ %y @ " " @ %z);
		%velocity = MatrixMulVector(%mat, %velocity);

		%p = new (%this.projectileType)()
		{
			dataBlock = %projectile;
			initialVelocity = %velocity;
			initialPosition = %obj.getMuzzlePoint(%slot);
			sourceObject = %obj;
			sourceSlot = %slot;
			client = %obj.client;
		};
		MissionCleanup.add(%p);
	}
	return %p;
}

function DDualFalchionsImage::onCharged(%this, %obj, %slot)
{	
		%obj.playThread(2, plant);
        serverPlay3D(DuelChargedSound,%obj.getPosition());

}

function DDualFalchionsImage::onSwing(%this, %obj, %slot)
{	
		%obj.playThread(2, plant);
        serverPlay3D(WooshFastestSound,%obj.getPosition());

}


function DDualFalchionsImage::onMount(%this, %obj, %slot)
{	

			%obj.hideNode("LHand");
			%obj.hideNode("RHand");
			%obj.hideNode("LHook");
			%obj.hideNode("RHook");
		%obj.playThread(0, armreadyboth);
}

function DDualFalchionsImage::onUnMount(%this, %obj, %slot)
{	

			%obj.unhideNode("LHand");
			%obj.unhideNode("RHand");
		%obj.playThread(0, root);
}