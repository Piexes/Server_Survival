datablock TSShapeConstructor(BearDts)
{
	baseShape  = "./Bear.dts";
	sequence0  = "./Bear_root.dsq root";

	sequence1  = "./Bear_Walk.dsq run";
	sequence2  = "./Bear_Walk.dsq walk";
	sequence3  = "./Bear_Walk.dsq back";
	sequence4  = "./Bear_Walk.dsq side";

	sequence5  = "./Bear_Root.dsq crouch";
	sequence6  = "./Bear_Sprint.dsq crouchRun";
	sequence7  = "./Bear_Walk.dsq crouchBack";
	sequence8  = "./Bear_Sprint.dsq crouchSide";

	sequence9  = "./Bear_Root.dsq look";
	sequence10 = "./Bear_root.dsq headside";
	sequence11 = "./Bear_root.dsq headUp";

	sequence12 = "./Bear_bite.dsq jump";
	sequence13 = "./Bear_bite.dsq standjump";
	sequence14 = "./Bear_Root.dsq fall";
	sequence15 = "./Bear_root.dsq land";

	sequence16 = "./Bear_biting.dsq armAttack";
	sequence17 = "./Bear_armready.dsq armReadyLeft";
	sequence18 = "./Bear_armready.dsq armReadyRight";
	sequence19 = "./Bear_mouthopen.dsq armReadyBoth";
	sequence20 = "./Bear_Root.dsq spearready";  
	sequence21 = "./Bear_root.dsq spearThrow";

	sequence22 = "./Bear_biting.dsq talk";  

	sequence23 = "./Bear_death.dsq death1"; 
	
	sequence24 = "./Bear_root.dsq shiftUp";
	sequence25 = "./Bear_root.dsq shiftDown";
	sequence26 = "./Bear_root.dsq shiftAway";
	sequence27 = "./Bear_root.dsq shiftTo";
	sequence28 = "./Bear_root.dsq shiftLeft";
	sequence29 = "./Bear_root.dsq shiftRight";
	sequence30 = "./Bear_root.dsq rotCW";
	sequence31 = "./Bear_root.dsq rotCCW";

	sequence32 = "./Bear_root.dsq undo";
	sequence33 = "./Bear_root.dsq plant";

	sequence34 = "./Bear_sit.dsq sit";

	sequence35 = "./Bear_root.dsq wrench";

   sequence36 = "./Bear_bite.dsq activate";
   sequence37 = "./Bear_bite.dsq activate2";

   sequence38 = "./Bear_root.dsq leftrecoil";
};  

datablock fxDTSBrickData (BrickBearBot_HoleSpawnData)
{
	brickFile = "Add-ons/Bot_Hole/6xspawn.blb";
	category = "Special";
	subCategory = "Holes";
	uiName = "Bear Hole";
	iconName = "Add-Ons/Bot_Bear/icon_Bear";

	bricktype = 2;
	cancover = 0;
	orientationfix = 1;
	indestructable = 1;

	isBotHole = 1;
	holeBot = "BearHoleBot";
};

// when the Bear brick is initially planted hide it, as most of the time we don't want it to exist since we're in the water
function BrickBearBot_HoleSpawnData::onPlant( %this, %obj )
{
	%obj.setRendering(0);
	%obj.setColliding(0);
	%obj.setRaycasting(0);
}

//Bear melee icon
AddDamageType("BearHoleBite",   '<bitmap:Add-Ons/Bot_Bear/CI_Bear> %1',    '%2 <bitmap:Add-Ons/Bot_Bear/CI_Bear> %1',0.5,1);


datablock PlayerData(BearHoleBot : PlayerStandardArmor)
{
	shapeFile = "./Bear.dts";
	uiName = "Bear";
	minJetEnergy = 0;
	jetEnergyDrain = 0;
	canJet = 0;
	maxItems   = 10;
	maxWeapons = 5;
	maxTools = 5;

	rideable = false;
	canRide = false;
	paintable = false;

	mass = 400;
	drag = 0.02;//0.02
	density = 0.80;//0.6
	runSurfaceAngle = 70;
	jumpSurfaceAngle = 70;
    runForce = 90 * 90;
   
   maxForwardSpeed = 5;
   maxBackwardSpeed = 5;
   maxSideSpeed = 2;

   maxForwardCrouchSpeed = 10;
   maxBackwardCrouchSpeed = 5;
   maxSideCrouchSpeed = 4;

   maxForwardProneSpeed = 0;
   maxBackwardProneSpeed = 0;
   maxSideProneSpeed = 0;

   maxForwardWalkSpeed = 5;
   maxBackwardWalkSpeed = 5;
   maxSideWalkSpeed = 2;

   maxUnderwaterForwardSpeed = 3;
   maxUnderwaterBackwardSpeed = 3;
   maxUnderwaterSideSpeed = 2;
   
	maxStepHeight = 1;

	showEnergyBar = false;

	jumpForce = 3000;

	boundingBox			= vectorScale("2.35 2.35 2.5", 4); //"2.5 2.5 2.4";
	crouchBoundingBox	= vectorScale("2.35 2.35 2.5", 4); //"2.5 2.5 2.4";
	proneBoundingBox	= vectorScale("2.35 2.35 2.5", 4); //"2.5 2.5 2.4";

	maxdamage = 300;//Bot Health
	jumpSound = "";//Removed due to bots jumping a lot
	
	//Hole Attributes
	isHoleBot = 1;

	//Spawning option
	hSpawnTooClose = 0;//Doesn't spawn when player is too close and can see it
	  hSpawnTCRange = 8;//above range, set in brick units
	hSpawnClose = 0;//Only spawn when close to a player, can be used with above function as long as hSCRange is higher than hSpawnTCRange
	  hSpawnCRange = 32;//above range, set in brick units

	hType = Bear; //Enemy,Friendly, Neutral
	  hNeutralAttackChance = 40;
	//can have unique types, nazis will attack zombies but nazis will not attack other bots labeled nazi
	hName = "Bear";//cannot contain spaces
	hTickRate = 3000;
	
	//Wander Options
	hWander = 1;//Enables random walking
	  hSmoothWander = 1;//This is in addition to regular wander, makes them walk a bit longer, and a bit smoother
	  hReturnToSpawn = 1;//Returns to spawn when too far
	  hSpawnDist = 48;//Defines the distance bot can travel away from spawnbrick
	  hGridWander = 0;//Locks the bot to a grid, overwrites other settings
	
	//Searching options
	hSearch = 1;//Search for Players
	  hSearchRadius = 64;//in brick units
	  hSight = 1;//Require bot to see player before pursuing
	  hStrafe = 0;//Randomly strafe while following player
	hSearchFOV = 0;//if enabled disables normal hSearch
	  hFOVRadius = 6;//max 10
	  hHearing = 1;//If it hears a player it'll look in the direction of the sound

	  hAlertOtherBots = 0;//Alerts other bots when he sees a player, or gets attacked

	//Attack Options
	hMelee = 1;//Melee
	  hAttackDamage = 35;//Melee Damage
	  	  hMeleeCI = "BearHoleBite";
	hShoot = 0;
	  hWep = "";
	  hShootTimes = 4;//Number of times the bot will shoot between each tick
	  hMaxShootRange = 256;//The range in which the bot will shoot the player
	  hAvoidCloseRange = 1;//
		hTooCloseRange = 7;//in brick units

	//Misc options
	hAvoidObstacles = 1;
	hSuperStacker = 0;//When enabled makes the bots stack a bit better, in other words, jumping on each others heads to get to a player
	hSpazJump = 0;//Makes bot jump when the user their following is higher than them

	hAFKOmeter = 1;//Determines how often the bot will wander or do other idle actions, higher it is the less often he does things

	hIdle = 1;// Enables use of idle actions, actions which are done when the bot is not doing anything else
	  hIdleAnimation = 0;//Plays random animations/emotes, sit, click, love/hate/etc
	  hIdleLookAtOthers = 1;//Randomly looks at other players/bots when not doing anything else
	    hIdleSpam = 0;//Makes them spam click and spam hammer/spraycan
	  hSpasticLook = 1;//Makes them look around their environment a bit more.
	hEmote = 1;
};

function BearHoleBot::onAdd(%this,%obj)
{
	armor::onAdd(%this,%obj);
	%color[%a++] = "0.60 0.40 0.20 1";
	%color[%a++] = "0.30 0.20 0.10 1";
	%color[%a++] = "0.15 0.15 0.15 1";
	%color[%a++] = "0.45 0.25 0.10 1";

	%choice = getRandom(1,%a);
	%obj.setNodeColor("ALL",%color[%choice]);
	%obj.setNodeColor("muzzle","0.70 0.55 0.35 1");
	%obj.chestColor =  %color[%choice];
	scheduleNoQuota(10,%obj,delayBearCheck,%obj);
}

function delayBearCheck(%obj)
{
	if(isObject(%obj))
	{
		if(%obj.name $= "Polar Bear")
		{
			%obj.setNodeColor("ALL","0.9 0.9 0.9 1.0");
			%obj.chestColor =  "0.9 0.9 0.9 1.0";
			%obj.hSearchRadius = 128;//in brick units
			%obj.hIsPolarBear = 1;
			%obj.hNeutralAttackChance = 80;
			%obj.hSpawnDist = 96;
			%obj.maxdamage = 400;
			%obj.hStrafe = 1;//Randomly strafe while following player
			%obj.hAttackDamage = 50;
			%obj.name = "Polar Bear";
		}
		if(%obj.name $= "Grizzly Bear")
		{
			%obj.setNodeColor("ALL","0.45 0.25 0.10 1");
			%obj.chestColor =  "0.45 0.25 0.10 1";
			%obj.setNodeColor("muzzle","0.70 0.55 0.35 1");
			%obj.hSearchRadius = 128;//in brick units
			%obj.hIsGrizzlyBear = 1;
			%obj.hNeutralAttackChance = 70;
			%obj.hSpawnDist = 64;
			%obj.maxdamage = 400;
			%obj.hAttackDamage = 50;
			%obj.name = "Grizzly Bear";
		}
		if(%obj.name $= "Black Bear")
		{
			%obj.setNodeColor("ALL","0.15 0.15 0.15 1");
			%obj.chestColor =  "0.15 0.15 0.15 1";
			%obj.setNodeColor("muzzle","0.70 0.55 0.35 1");
			%obj.hIsBlackBear = 1;
			%obj.hNeutralAttackChance = 30;
			%obj.name = "Black Bear";
		}
	}
}

function BearHoleBot::onBotLoop(%this,%obj)
{
	//Called every cycle
	//Useful for doing unique behaviors during normal loop
}

function BearHoleBot::onBotCollision( %this, %obj, %col, %normal, %speed )
{
	//Called once every second the object is colliding with something
}

function BearHoleBot::onBotFollow(%this,%obj,%targ)
{
	//Called when the target follows a player each tick, or is running away
}

function BearHoleBot::onBotDamage(%this,%obj,%source,%pos,%damage,%type)
{
	//Called when the bot is being damaged
}
