//Base Blockhead guy
if(LoadRequiredAddOn("Bot_Hole") == $Error::None)
{
	exec("./bot_Skeleton.cs");
	exec("./bot_Skeleton_Archer.cs");
	exec("./bot_Skeleton_Armored.cs");
}