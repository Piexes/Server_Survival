datablock TSShapeConstructor(TriceratopsDts)
{
	baseShape  = "./Triceratops.dts";
	sequence0  = "./Triceratops_root.dsq root";

	sequence1  = "./Triceratops_Walk.dsq run";
	sequence2  = "./Triceratops_Walk.dsq walk";
	sequence3  = "./Triceratops_Walk.dsq back";
	sequence4  = "./Triceratops_Walk.dsq side";

	sequence5  = "./Triceratops_Root.dsq crouch";
	sequence6  = "./Triceratops_Sprint.dsq crouchRun";
	sequence7  = "./Triceratops_Walk.dsq crouchBack";
	sequence8  = "./Triceratops_Sprint.dsq crouchSide";

	sequence9  = "./Triceratops_Root.dsq look";
	sequence10 = "./Triceratops_root.dsq headside";
	sequence11 = "./Triceratops_root.dsq headUp";

	sequence12 = "./Triceratops_Root.dsq jump";
	sequence13 = "./Triceratops_Root.dsq standjump";
	sequence14 = "./Triceratops_Root.dsq fall";
	sequence15 = "./Triceratops_root.dsq land";

	sequence16 = "./Triceratops_biting.dsq armAttack";
	sequence17 = "./Triceratops_armready.dsq armReadyLeft";
	sequence18 = "./Triceratops_armready.dsq armReadyRight";
	sequence19 = "./Triceratops_mouthopen.dsq armReadyBoth";
	sequence20 = "./Triceratops_Root.dsq spearready";  
	sequence21 = "./Triceratops_root.dsq spearThrow";

	sequence22 = "./Triceratops_biting.dsq talk";  

	sequence23 = "./Triceratops_death.dsq death1"; 
	
	sequence24 = "./Triceratops_root.dsq shiftUp";
	sequence25 = "./Triceratops_root.dsq shiftDown";
	sequence26 = "./Triceratops_root.dsq shiftAway";
	sequence27 = "./Triceratops_root.dsq shiftTo";
	sequence28 = "./Triceratops_root.dsq shiftLeft";
	sequence29 = "./Triceratops_root.dsq shiftRight";
	sequence30 = "./Triceratops_root.dsq rotCW";
	sequence31 = "./Triceratops_root.dsq rotCCW";

	sequence32 = "./Triceratops_root.dsq undo";
	sequence33 = "./Triceratops_root.dsq plant";

	sequence34 = "./Triceratops_root.dsq sit";

	sequence35 = "./Triceratops_root.dsq wrench";

   sequence36 = "./Triceratops_bite.dsq activate";
   sequence37 = "./Triceratops_bite.dsq activate2";

   sequence38 = "./Triceratops_root.dsq leftrecoil";
};  

datablock fxDTSBrickData (BrickTriceratopsBot_HoleSpawnData)
{
	brickFile = "Add-ons/Bot_Hole/6xspawn.blb";
	category = "Special";
	subCategory = "Holes";
	uiName = "Triceratops Hole";
	iconName = "Add-Ons/Bot_Dinosaurs/icon_Triceratops";

	bricktype = 2;
	cancover = 0;
	orientationfix = 1;
	indestructable = 1;

	isBotHole = 1;
	holeBot = "TriceratopsHoleBot";
};

// when the Triceratops brick is initially planted hide it, as most of the time we don't want it to exist since we're in the water
function BrickTriceratopsBot_HoleSpawnData::onPlant( %this, %obj )
{
	%obj.setRendering(0);
	%obj.setColliding(0);
	%obj.setRaycasting(0);
}

datablock PlayerData(TriceratopsHoleBot : PlayerStandardArmor)
{
	shapeFile = "./Triceratops.dts";
	uiName = "Dinosaur Triceratops";
	minJetEnergy = 0;
	jetEnergyDrain = 0;
	canJet = 0;
	maxItems   = 10;
	maxWeapons = 5;
	maxTools = 5;

	rideable = false;
	canRide = false;
	paintable = false;

	mass = 400;
	drag = 0.02;//0.02
	density = 0.80;//0.6
	runSurfaceAngle = 70;
	jumpSurfaceAngle = 70;
    runForce = 90 * 90;
   
   maxForwardSpeed = 5;
   maxBackwardSpeed = 5;
   maxSideSpeed = 2;

   maxForwardCrouchSpeed = 16;
   maxBackwardCrouchSpeed = 5;
   maxSideCrouchSpeed = 4;

   maxForwardProneSpeed = 0;
   maxBackwardProneSpeed = 0;
   maxSideProneSpeed = 0;

   maxForwardWalkSpeed = 5;
   maxBackwardWalkSpeed = 5;
   maxSideWalkSpeed = 2;

   maxUnderwaterForwardSpeed = 3;
   maxUnderwaterBackwardSpeed = 3;
   maxUnderwaterSideSpeed = 2;
   
	maxStepHeight = 1;

	showEnergyBar = false;

	jumpForce = 0;

	boundingBox			= vectorScale("2.75 2.75 3", 4); //"2.5 2.5 2.4";
	crouchBoundingBox	= vectorScale("2.75 2.75 3", 4); //"2.5 2.5 2.4";
	proneBoundingBox	= vectorScale("2.75 2.75 3", 4); //"2.5 2.5 2.4";

	maxdamage = 500;//Bot Health
	jumpSound = "";//Removed due to bots jumping a lot
	
	//Hole Attributes
	isHoleBot = 1;

	//Spawning option
	hSpawnTooClose = 0;//Doesn't spawn when player is too close and can see it
	  hSpawnTCRange = 8;//above range, set in brick units
	hSpawnClose = 0;//Only spawn when close to a player, can be used with above function as long as hSCRange is higher than hSpawnTCRange
	  hSpawnCRange = 32;//above range, set in brick units

	hType = Neutral; //Enemy,Friendly, Neutral
	  hNeutralAttackChance = 0;
	//can have unique types, nazis will attack zombies but nazis will not attack other bots labeled nazi
	hName = "Triceratops";//cannot contain spaces
	hTickRate = 3000;
	
	//Wander Options
	hWander = 1;//Enables random walking
	  hSmoothWander = 1;//This is in addition to regular wander, makes them walk a bit longer, and a bit smoother
	  hReturnToSpawn = 0;//Returns to spawn when too far
	  hSpawnDist = 48;//Defines the distance bot can travel away from spawnbrick
	  hGridWander = 0;//Locks the bot to a grid, overwrites other settings
	
	//Searching options
	hSearch = 0;//Search for Players
	  hSearchRadius = 64;//in brick units
	  hSight = 1;//Require bot to see player before pursuing
	  hStrafe = 1;//Randomly strafe while following player
	hSearchFOV = 0;//if enabled disables normal hSearch
	  hFOVRadius = 6;//max 10
	  hHearing = 1;//If it hears a player it'll look in the direction of the sound

	  hAlertOtherBots = 1;//Alerts other bots when he sees a player, or gets attacked

	//Attack Options
	hMelee = 0;//Melee
	  hAttackDamage = 15;//Melee Damage
	hShoot = 0;
	  hWep = "gunImage";
	  hShootTimes = 4;//Number of times the bot will shoot between each tick
	  hMaxShootRange = 256;//The range in which the bot will shoot the player
	  hAvoidCloseRange = 1;//
		hTooCloseRange = 7;//in brick units

	//Misc options
	hAvoidObstacles = 1;
	hSuperStacker = 0;//When enabled makes the bots stack a bit better, in other words, jumping on each others heads to get to a player
	hSpazJump = 0;//Makes bot jump when the user their following is higher than them

	hAFKOmeter = 1;//Determines how often the bot will wander or do other idle actions, higher it is the less often he does things

	hIdle = 1;// Enables use of idle actions, actions which are done when the bot is not doing anything else
	  hIdleAnimation = 0;//Plays random animations/emotes, sit, click, love/hate/etc
	  hIdleLookAtOthers = 1;//Randomly looks at other players/bots when not doing anything else
	    hIdleSpam = 0;//Makes them spam click and spam hammer/spraycan
	  hSpasticLook = 1;//Makes them look around their environment a bit more.
	hEmote = 1;
};

function TriceratopsHoleBot::onAdd(%this,%obj)
{
	armor::onAdd(%this,%obj);
	%color[%a++] = "0.20 0.40 0.25 1";  //green
	%color[%a++] = "0.25 0.50 0.35 1";
	%color[%a++] = "0.35 0.55 0.50 1";  //bluegreen
	%color[%a++] = "0.25 0.35 0.40 1";
	%color[%a++] = "0.30 0.40 0.50 1";	//blue

	%choice = getRandom(1,%a);
	%obj.setNodeColor("ALL",%color[%choice]);
	%obj.chestColor =  %color[%choice];
}

function TriceratopsHoleBot::onBotLoop(%this,%obj)
{
	//Called every cycle
	//Useful for doing unique behaviors during normal loop
}

function TriceratopsHoleBot::onBotCollision( %this, %obj, %col, %normal, %speed )
{
	//Called once every second the object is colliding with something
	//echo(%obj.isStampeding SPC %col.isHoleBot SPC %obj.getState() !$= "Dead" SPC %col.getState() !$= "Dead" SPC !%col.isStampeding SPC %col.getDataBlock().getName() $= "TriceratopsHoleBot");
	if(%obj.isStampeding && %col.isHoleBot && %obj.getState() !$= "Dead" && %col.getState() !$= "Dead" && !%col.isStampeding && %col.getDataBlock().getName() $= "TriceratopsHoleBot")
	{
		//echo("Spreading stampede");
		%col.emote("AlarmProjectile");
		%col.stopHoleLoop();
		hDoStampede(%col);
		scheduleNoQuota(4000+getRandom(-750,750),%col,hDoStampede,%col);
		scheduleNoQuota(8000+getRandom(-750,750),%col,hDoStampede,%col);
		scheduleNoQuota(12000,%col,hStopStampede,%col);
	}
}

function TriceratopsHoleBot::onBotFollow(%this,%obj,%targ)
{
	//Called when the target follows a player each tick, or is running away
}

function TriceratopsHoleBot::onBotDamage(%this,%obj,%source,%pos,%damage,%type)
{
	//Called when the bot is being damaged
	if(!%obj.isStampeding && %obj.getState() !$= "Dead" && !%obj.hMelee)
	{
		%obj.stopHoleLoop();
		%obj.emote("AlarmProjectile");
		hDoStampede(%obj);
		scheduleNoQuota(4000+getRandom(-750,750),%obj,hDoStampede,%obj);
		scheduleNoQuota(8000+getRandom(-750,750),%obj,hDoStampede,%obj);
		scheduleNoQuota(12000,%obj,hStopStampede,%obj);
	}
	// %driver = %obj.getMountedObject(0);
	// if( isObject(%driver) && %obj.getDamagePercent() >= 0.5)
	// {
	// if( !getRandom( 0, 1 ) )
	if( %obj.getDamagePercent() >= 0.5 )
		%obj.scheduleNoQuota( 200, ejectRandomPlayer );
	// }
}

function hDoStampede(%obj)
{
	if(%obj.hMelee)
		return;
	
	// %obj.setImageTrigger(2,1);
	%obj.setCrouching(1);
	//%obj.setImageTrigger(2,0);

	%obj.isStampeding = 1;

	%x = hGetRandomFloat(0,10,1);

	%y = hGetRandomFloat(0,10,1);
	
	%z = hGetRandomFloat(0,3,1);

	%vec = %x SPC %y SPC %z;
	// hSetAimVector(%obj,%vec);
	%obj.setAimVector( %vec );

	%obj.setMoveY(1);//hGetRandomFloat(6,10,0));

	%obj.hAvoidObstacle();
	%obj.hDetectWall(1);
	// hAvoidObstacle(%obj);
	// hWanderSearchWall(%obj,1);

	//schedule(3000,%obj,hAvoidObstacle,%obj,1);
	
	//%obj.schedule(7000,startHoleLoop);
}

function hStopStampede(%obj)
{
	%obj.startHoleLoop();
	%obj.isStampeding = 0;
}