datablock TSShapeConstructor(StegosaurDts)
{
	baseShape  = "./Stegosaur.dts";
	sequence0  = "./Stego_root.dsq root";

	sequence1  = "./Stego_walk.dsq run";
	sequence2  = "./Stego_walk.dsq walk";
	sequence3  = "./Stego_walk.dsq back";
	sequence4  = "./Stego_walk.dsq side";

	sequence5  = "./Stego_root.dsq crouch";
	sequence6  = "./Stego_Sprint.dsq crouchRun";
	sequence7  = "./Stego_Walk.dsq crouchBack";
	sequence8  = "./Stego_Sprint.dsq crouchSide";

	sequence9  = "./Stego_root.dsq look";
	sequence10 = "./Stego_root.dsq headside";
	sequence11 = "./Stego_root.dsq headUp";

	sequence12 = "./Stego_root.dsq jump";
	sequence13 = "./Stego_root.dsq standjump";
	sequence14 = "./Stego_root.dsq fall";
	sequence15 = "./Stego_root.dsq land";

	sequence16 = "./Stego_biting.dsq armAttack";
	sequence17 = "./Stego_armready.dsq armReadyLeft";
	sequence18 = "./Stego_armready.dsq armReadyRight";
	sequence19 = "./Stego_mouthopen.dsq armReadyBoth";
	sequence20 = "./Stego_root.dsq spearready";  
	sequence21 = "./Stego_root.dsq spearThrow";

	sequence22 = "./Stego_biting.dsq talk";  

	sequence23 = "./Stego_death.dsq death1"; 
	
	sequence24 = "./Stego_root.dsq shiftUp";
	sequence25 = "./Stego_root.dsq shiftDown";
	sequence26 = "./Stego_root.dsq shiftAway";
	sequence27 = "./Stego_root.dsq shiftTo";
	sequence28 = "./Stego_root.dsq shiftLeft";
	sequence29 = "./Stego_root.dsq shiftRight";
	sequence30 = "./Stego_root.dsq rotCW";
	sequence31 = "./Stego_root.dsq rotCCW";

	sequence32 = "./Stego_root.dsq undo";
	sequence33 = "./Stego_root.dsq plant";

	sequence34 = "./Stego_root.dsq sit";

	sequence35 = "./Stego_root.dsq wrench";

   sequence36 = "./Stego_bite.dsq activate";
   sequence37 = "./Stego_bite.dsq activate2";

   sequence38 = "./Stego_root.dsq leftrecoil";
};  

datablock fxDTSBrickData (BrickStegosaurBot_HoleSpawnData)
{
	brickFile = "Add-ons/Bot_Hole/6xspawn.blb";
	category = "Special";
	subCategory = "Holes";
	uiName = "Stegosaur Hole";
	iconName = "Add-Ons/Bot_Dinosaurs/icon_Stegosaur";

	bricktype = 2;
	cancover = 0;
	orientationfix = 1;
	indestructable = 1;

	isBotHole = 1;
	holeBot = "StegosaurHoleBot";
};

// when the Stegosaur brick is initially planted hide it, as most of the time we don't want it to exist since we're in the water
function BrickStegosaurBot_HoleSpawnData::onPlant( %this, %obj )
{
	%obj.setRendering(0);
	%obj.setColliding(0);
	%obj.setRaycasting(0);
}

datablock PlayerData(StegosaurHoleBot : PlayerStandardArmor)
{
	shapeFile = "./Stegosaur.dts";
	uiName = "Dinosaur Stegosaur";
	minJetEnergy = 0;
	jetEnergyDrain = 0;
	canJet = 0;
	maxItems   = 10;
	maxWeapons = 5;
	maxTools = 5;

	rideable = false;
	canRide = false;
	paintable = false;

	mass = 400;
	drag = 0.02;//0.02
	density = 0.80;//0.6
	runSurfaceAngle = 70;
	jumpSurfaceAngle = 70;
    runForce = 90 * 90;
   
   maxForwardSpeed = 5;
   maxBackwardSpeed = 5;
   maxSideSpeed = 2;

   maxForwardCrouchSpeed = 14;
   maxBackwardCrouchSpeed = 5;
   maxSideCrouchSpeed = 4;

   maxForwardProneSpeed = 0;
   maxBackwardProneSpeed = 0;
   maxSideProneSpeed = 0;

   maxForwardWalkSpeed = 5;
   maxBackwardWalkSpeed = 5;
   maxSideWalkSpeed = 2;

   maxUnderwaterForwardSpeed = 3;
   maxUnderwaterBackwardSpeed = 3;
   maxUnderwaterSideSpeed = 2;
   
	maxStepHeight = 1;

	showEnergyBar = false;

	jumpForce = 0;

	boundingBox			= vectorScale("2.75 2.75 4", 4); //"2.5 2.5 2.4";
	crouchBoundingBox	= vectorScale("2.75 2.75 4", 4); //"2.5 2.5 2.4";
	proneBoundingBox	= vectorScale("2.75 2.75 4", 4); //"2.5 2.5 2.4";

	maxdamage = 500;//Bot Health
	jumpSound = "";//Removed due to bots jumping a lot
	
	//Hole Attributes
	isHoleBot = 1;

	//Spawning option
	hSpawnTooClose = 0;//Doesn't spawn when player is too close and can see it
	  hSpawnTCRange = 8;//above range, set in brick units
	hSpawnClose = 0;//Only spawn when close to a player, can be used with above function as long as hSCRange is higher than hSpawnTCRange
	  hSpawnCRange = 32;//above range, set in brick units

	hType = Neutral; //Enemy,Friendly, Neutral
	  hNeutralAttackChance = 0;
	//can have unique types, nazis will attack zombies but nazis will not attack other bots labeled nazi
	hName = "Stegosaur";//cannot contain spaces
	hTickRate = 3000;
	
	//Wander Options
	hWander = 1;//Enables random walking
	  hSmoothWander = 1;//This is in addition to regular wander, makes them walk a bit longer, and a bit smoother
	  hReturnToSpawn = 0;//Returns to spawn when too far
	  hSpawnDist = 48;//Defines the distance bot can travel away from spawnbrick
	  hGridWander = 0;//Locks the bot to a grid, overwrites other settings
	
	//Searching options
	hSearch = 0;//Search for Players
	  hSearchRadius = 64;//in brick units
	  hSight = 1;//Require bot to see player before pursuing
	  hStrafe = 1;//Randomly strafe while following player
	hSearchFOV = 0;//if enabled disables normal hSearch
	  hFOVRadius = 6;//max 10
	  hHearing = 1;//If it hears a player it'll look in the direction of the sound

	  hAlertOtherBots = 1;//Alerts other bots when he sees a player, or gets attacked

	//Attack Options
	hMelee = 0;//Melee
	  hAttackDamage = 15;//Melee Damage
	hShoot = 0;
	  hWep = "gunImage";
	  hShootTimes = 4;//Number of times the bot will shoot between each tick
	  hMaxShootRange = 256;//The range in which the bot will shoot the player
	  hAvoidCloseRange = 1;//
		hTooCloseRange = 7;//in brick units

	//Misc options
	hAvoidObstacles = 1;
	hSuperStacker = 0;//When enabled makes the bots stack a bit better, in other words, jumping on each others heads to get to a player
	hSpazJump = 0;//Makes bot jump when the user their following is higher than them

	hAFKOmeter = 1;//Determines how often the bot will wander or do other idle actions, higher it is the less often he does things

	hIdle = 1;// Enables use of idle actions, actions which are done when the bot is not doing anything else
	  hIdleAnimation = 0;//Plays random animations/emotes, sit, click, love/hate/etc
	  hIdleLookAtOthers = 1;//Randomly looks at other players/bots when not doing anything else
	    hIdleSpam = 0;//Makes them spam click and spam hammer/spraycan
	  hSpasticLook = 1;//Makes them look around their environment a bit more.
	hEmote = 1;
};

function StegosaurHoleBot::onAdd(%this,%obj)
{
	armor::onAdd(%this,%obj);
	%color[%a++] = "0.40 0.50 0.25 1";  //green
	%color[%a++] = "0.50 0.50 0.30 1";
	%color[%a++] = "0.45 0.40 0.35 1";  //graybrown
	%color[%a++] = "0.65 0.55 0.40 1";
	%color[%a++] = "0.45 0.30 0.15 1";  //brown

	%choice = getRandom(1,%a);
	%obj.setNodeColor("ALL",%color[%choice]);
	%obj.chestColor =  %color[%choice];
}

function StegosaurHoleBot::onBotLoop(%this,%obj)
{
	//Called every cycle
	//Useful for doing unique behaviors during normal loop
}

function StegosaurHoleBot::onBotCollision( %this, %obj, %col, %normal, %speed )
{
	//Called once every second the object is colliding with something
	//echo(%obj.isStampeding SPC %col.isHoleBot SPC %obj.getState() !$= "Dead" SPC %col.getState() !$= "Dead" SPC !%col.isStampeding SPC %col.getDataBlock().getName() $= "StegosaurHoleBot");
	if(%obj.isStampeding && %col.isHoleBot && %obj.getState() !$= "Dead" && %col.getState() !$= "Dead" && !%col.isStampeding && %col.getDataBlock().getName() $= "StegosaurHoleBot")
	{
		//echo("Spreading stampede");
		%col.emote("AlarmProjectile");
		%col.stopHoleLoop();
		hDoStampede(%col);
		scheduleNoQuota(4000+getRandom(-750,750),%col,hDoStampede,%col);
		scheduleNoQuota(8000+getRandom(-750,750),%col,hDoStampede,%col);
		scheduleNoQuota(12000,%col,hStopStampede,%col);
	}
}

function StegosaurHoleBot::onBotFollow(%this,%obj,%targ)
{
	//Called when the target follows a player each tick, or is running away
}

function StegosaurHoleBot::onBotDamage(%this,%obj,%source,%pos,%damage,%type)
{
	//Called when the bot is being damaged
	if(!%obj.isStampeding && %obj.getState() !$= "Dead" && !%obj.hMelee)
	{
		%obj.stopHoleLoop();
		%obj.emote("AlarmProjectile");
		hDoStampede(%obj);
		scheduleNoQuota(4000+getRandom(-750,750),%obj,hDoStampede,%obj);
		scheduleNoQuota(8000+getRandom(-750,750),%obj,hDoStampede,%obj);
		scheduleNoQuota(12000,%obj,hStopStampede,%obj);
	}
	// %driver = %obj.getMountedObject(0);
	// if( isObject(%driver) && %obj.getDamagePercent() >= 0.5)
	// {
	// if( !getRandom( 0, 1 ) )
	if( %obj.getDamagePercent() >= 0.5 )
		%obj.scheduleNoQuota( 200, ejectRandomPlayer );
	// }
}

function hDoStampede(%obj)
{
	if(%obj.hMelee)
		return;
	
	// %obj.setImageTrigger(2,1);
	%obj.setCrouching(1);
	//%obj.setImageTrigger(2,0);

	%obj.isStampeding = 1;

	%x = hGetRandomFloat(0,10,1);

	%y = hGetRandomFloat(0,10,1);
	
	%z = hGetRandomFloat(0,3,1);

	%vec = %x SPC %y SPC %z;
	// hSetAimVector(%obj,%vec);
	%obj.setAimVector( %vec );

	%obj.setMoveY(1);//hGetRandomFloat(6,10,0));

	%obj.hAvoidObstacle();
	%obj.hDetectWall(1);
	// hAvoidObstacle(%obj);
	// hWanderSearchWall(%obj,1);

	//schedule(3000,%obj,hAvoidObstacle,%obj,1);
	
	//%obj.schedule(7000,startHoleLoop);
}

function hStopStampede(%obj)
{
	%obj.startHoleLoop();
	%obj.isStampeding = 0;
}