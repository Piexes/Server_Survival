datablock TSShapeConstructor(RaptorDts)
{
	baseShape  = "./Raptor.dts";
	sequence0  = "./Raptor_root.dsq root";

	sequence1  = "./Raptor_Walk.dsq run";
	sequence2  = "./Raptor_Walk.dsq walk";
	sequence3  = "./Raptor_Walk.dsq back";
	sequence4  = "./Raptor_Walk.dsq side";

	sequence5  = "./Raptor_Root.dsq crouch";
	sequence6  = "./Raptor_Sprint.dsq crouchRun";
	sequence7  = "./Raptor_Walk.dsq crouchBack";
	sequence8  = "./Raptor_Sprint.dsq crouchSide";

	sequence9  = "./Raptor_look.dsq look";
	sequence10 = "./Raptor_root.dsq headside";
	sequence11 = "./Raptor_root.dsq headUp";

	sequence12 = "./Raptor_jump.dsq jump";
	sequence13 = "./Raptor_jump.dsq standjump";
	sequence14 = "./Raptor_jump.dsq fall";
	sequence15 = "./Raptor_pounce.dsq land";

	sequence16 = "./Raptor_biting.dsq armAttack";
	sequence17 = "./Raptor_a.dsq armReadyLeft";
	sequence18 = "./Raptor_armready.dsq armReadyRight";
	sequence19 = "./Raptor_armsup.dsq armReadyBoth";
	sequence20 = "./Raptor_mouthopen.dsq spearready";  
	sequence21 = "./Raptor_root.dsq spearThrow";

	sequence22 = "./Raptor_biting.dsq talk";  

	sequence23 = "./Raptor_death.dsq death1"; 
	
	sequence24 = "./Raptor_root.dsq shiftUp";
	sequence25 = "./Raptor_root.dsq shiftDown";
	sequence26 = "./Raptor_root.dsq shiftAway";
	sequence27 = "./Raptor_root.dsq shiftTo";
	sequence28 = "./Raptor_root.dsq shiftLeft";
	sequence29 = "./Raptor_root.dsq shiftRight";
	sequence30 = "./Raptor_root.dsq rotCW";
	sequence31 = "./Raptor_root.dsq rotCCW";

	sequence32 = "./Raptor_root.dsq undo";
	sequence33 = "./Raptor_root.dsq plant";

	sequence34 = "./Raptor_sit.dsq sit";

	sequence35 = "./Raptor_root.dsq wrench";

   sequence36 = "./Raptor_activate.dsq activate";
   sequence37 = "./Raptor_bite.dsq activate2";

   sequence38 = "./Raptor_root.dsq leftrecoil";
};  

datablock fxDTSBrickData (BrickRaptorBot_HoleSpawnData)
{
	brickFile = "Add-ons/Bot_Hole/4xspawn.blb";
	category = "Special";
	subCategory = "Holes";
	uiName = "Raptor Hole";
	iconName = "Add-Ons/Bot_Dinosaurs/icon_Raptor";

	bricktype = 2;
	cancover = 0;
	orientationfix = 1;
	indestructable = 1;

	isBotHole = 1;
	holeBot = "RaptorHoleBot";
};

// when the Raptor brick is initially planted hide it, as most of the time we don't want it to exist since we're in the water
function BrickRaptorBot_HoleSpawnData::onPlant( %this, %obj )
{
	%obj.setRendering(0);
	%obj.setColliding(0);
	%obj.setRaycasting(0);
}

//Raptor melee icon
AddDamageType("RaptorHoleBite",   '<bitmap:Add-Ons/Bot_Dinosaurs/CI_Raptor> %1',    '%2 <bitmap:Add-Ons/Bot_Dinosaurs/CI_Raptor> %1',0.5,1);


datablock PlayerData(RaptorHoleBot : PlayerStandardArmor)
{
	shapeFile = "./Raptor.dts";
	uiName = "Dinosaur Raptor";
	minJetEnergy = 0;
	jetEnergyDrain = 0;
	canJet = 0;
	maxItems   = 10;
	maxWeapons = 5;
	maxTools = 5;

	rideable = false;
	canRide = false;
	paintable = false;

	mass = 200;
	drag = 0.02;//0.02
	density = 0.80;//0.6
	runSurfaceAngle = 70;
	jumpSurfaceAngle = 70;
    runForce = 90 * 90;
   
   maxForwardSpeed = 5;
   maxBackwardSpeed = 5;
   maxSideSpeed = 2;

   maxForwardCrouchSpeed = 20;
   maxBackwardCrouchSpeed = 5;
   maxSideCrouchSpeed = 4;

   maxForwardProneSpeed = 0;
   maxBackwardProneSpeed = 0;
   maxSideProneSpeed = 0;

   maxForwardWalkSpeed = 5;
   maxBackwardWalkSpeed = 5;
   maxSideWalkSpeed = 2;

   maxUnderwaterForwardSpeed = 5;
   maxUnderwaterBackwardSpeed = 5;
   maxUnderwaterSideSpeed = 2;
   
	maxStepHeight = 1;

	showEnergyBar = false;
	
	jumpForce = 2400;

	boundingBox			= vectorScale("1.25 1.25 2.5", 4); //"2.5 2.5 2.4";
	crouchBoundingBox	= vectorScale("1.25 1.25 2.5", 4); //"2.5 2.5 2.4";
	proneBoundingBox	= vectorScale("1.25 1.25 2.5", 4); //"2.5 2.5 2.4";

	maxdamage = 300;//Bot Health
	jumpSound = "";//Removed due to bots jumping a lot
	
	//Hole Attributes
	isHoleBot = 1;

	//Spawning option
	hSpawnTooClose = 0;//Doesn't spawn when player is too close and can see it
	  hSpawnTCRange = 8;//above range, set in brick units
	hSpawnClose = 0;//Only spawn when close to a player, can be used with above function as long as hSCRange is higher than hSpawnTCRange
	  hSpawnCRange = 32;//above range, set in brick units

	hType = Raptor; //Enemy,Friendly, Neutral
	  hNeutralAttackChance = 60;
	//can have unique types, nazis will attack zombies but nazis will not attack other bots labeled nazi
	hName = "Raptor";//cannot contain spaces
	hTickRate = 3000;
	
	//Wander Options
	hWander = 1;//Enables random walking
	  hSmoothWander = 1;//This is in addition to regular wander, makes them walk a bit longer, and a bit smoother
	  hReturnToSpawn = 0;//Returns to spawn when too far
	  hSpawnDist = 48;//Defines the distance bot can travel away from spawnbrick
	  hGridWander = 0;//Locks the bot to a grid, overwrites other settings
	
	//Searching options
	hSearch = 1;//Search for Players
	  hSearchRadius = 96;//in brick units
	  hSight = 1;//Require bot to see player before pursuing
	  hStrafe = 0;//Randomly strafe while following player
	hSearchFOV = 0;//if enabled disables normal hSearch
	hFOVRange = 0.7;
	  hFOVRadius = 5;//max 10
	  hHearing = 1;//If it hears a player it'll look in the direction of the sound

	  hAlertOtherBots = 1;//Alerts other bots when he sees a player, or gets attacked

	//Attack Options
	hMelee = 1;//Melee
	  hAttackDamage = 30;//Melee Damage
	  hMeleeCI = "RaptorHoleBite";
	hShoot = 0;
	  hWep = "";
	  hShootTimes = 4;//Number of times the bot will shoot between each tick
	  hMaxShootRange = 256;//The range in which the bot will shoot the player
	  hAvoidCloseRange = 1;//
		hTooCloseRange = 7;//in brick units

	//Misc options
	hAvoidObstacles = 1;
	hSuperStacker = 1;//When enabled makes the bots stack a bit better, in other words, jumping on each others heads to get to a player
	hSpazJump = 1;//Makes bot jump when the user their following is higher than them

	hAFKOmeter = 1;//Determines how often the bot will wander or do other idle actions, higher it is the less often he does things

	hIdle = 1;// Enables use of idle actions, actions which are done when the bot is not doing anything else
	  hIdleAnimation = 1;//Plays random animations/emotes, sit, click, love/hate/etc
	  hIdleLookAtOthers = 1;//Randomly looks at other players/bots when not doing anything else
	    hIdleSpam = 0;//Makes them spam click and spam hammer/spraycan
	  hSpasticLook = 1;//Makes them look around their environment a bit more.
	hEmote = 1;
};

function RaptorHoleBot::onAdd(%this,%obj)
{
	armor::onAdd(%this,%obj);
	%obj.hIsRaptor = 1;
	%color[%a++] = "0.00 0.60 0.25 1";
	%color[%a++] = "0.20 0.60 0.35 1";
	%color[%a++] = "0.40 0.60 0.35 1";
	%color[%a++] = "0.50 0.60 0.25 1";
	%color[%a++] = "0.60 0.60 0.25 1";

	%choice = getRandom(1,%a);
	%obj.setNodeColor("ALL",%color[%choice]);
	%obj.chestColor =  %color[%choice];

	// %obj.invulnerable = 1;
	
	// if( isObject(%obj.spawnBrick) )
	// {
		// %obj.spawnBrick.setRendering(0);
		// %obj.spawnBrick.setColliding(0);
		// %obj.spawnBrick.setRaycasting(0);
	// }
	
}

function RaptorHoleBot::onNewDataBlock(%this,%obj)
{
	%color[%a++] = "0.00 0.60 0.25 1";
	%color[%a++] = "0.20 0.60 0.35 1";
	%color[%a++] = "0.40 0.60 0.35 1";
	%color[%a++] = "0.50 0.60 0.25 1";
	%color[%a++] = "0.60 0.60 0.25 1";

	%obj.setNodeColor("ALL",%color[getRandom(1,%a)]);
}

function RaptorHoleBot::onBotLoop(%this,%obj)
{
	%obj.stopThread(1);
	%obj.stopThread(0);
	//Called every cycle
	//Useful for doing unique behaviors during normal loop
}

function RaptorHoleBot::onBotCollision( %this, %obj, %col, %normal, %speed )
{
	 if( %obj.isDisabled() )
		return;

	%canDamage = miniGameCanDamage(%obj,%col);
		
	if( isObject(%obj.hEating) || %obj.getMountedObject( 0 ) || %col.isDisabled() || %canDamage == 0 || %canDamage == -1 ) // !checkHoleBotTeams(%obj,%col) ||
		return;
		
	//Check if we can attack, then check if it's a minifig, then eat him//%col.isHoleBot &&
	%oScale = getWord(%obj.getScale(),0);
	%cScale = getWord(%col.getScale(),0);
	// if( (!getRandom(0,1)|| %obj.hIsMegaRaptor) && %obj.getState() !$= "Dead" && checkHoleBotTeams(%obj,%col) && !isObject(%obj.hEating) && %col.getState() !$= "Dead" && miniGameCanDamage(%obj,%col) == 1)
	
	// if we collide with a vehicle then eject the player
	// this may cause some funky things, but it should be entertaining
	%wasEjected = 0;
	
	// %checkTeam = checkHoleBotTeams(%obj,%col);
	
	if( %col.getMountedObjectCount() && ( !getRandom( 0, 1 ) || %obj.hIsMegaRaptor || ( %col.getType() & $TypeMasks::VehicleObjectType ) ) )
	{
		if( %col.hIsRaptor && %col.getMountedObject( 0 ).hIsRaptor )
			return;
	
		%col = %col.ejectRandomPlayer();
		%wasEjected = 1;
		
		if( %col.client )
			%col.client.setControlObject( %col );
	}
	
	%checkTeam = checkHoleBotTeams(%obj,%col);
	
	if( ( !getRandom(0,1)|| %obj.hIsMegaRaptor || %wasEjected ) && %checkTeam )
	{
		if(  %oScale+0.7 >= %cScale && %col.getDataBlock().shapeFile $= "base/data/shapes/player/m.dts")
		{
			if(%col.getClassName() $= "Player" && %col.client)
			{
				%col.client.camera.setOrbitMode(%obj, %obj.getTransform(), 0, 10, 0, 1);
				%col.client.setControlObject(%col.client.camera);
				//hSpazzClick(%col,0,1);
			}
			%obj.stopHoleLoop();
			// %obj.setImageTrigger(3,1);
			%obj.playThread(1,pounce);
			%obj.playThread(0,biting);
			%obj.mountObject(%col,2);
			
			%obj.hIgnore = %col;
			%obj.hEating = %col;
			%obj.hLastEatTime = getSimTime();
			
			// temporarily set the Raptor to invulnerable when he eats someone to avoid getting
			%obj.invulnerable = true;
			schedule( 200, %obj, eval, %obj @ ".invulnerable = false;" );

			%obj.hRaptorEatDelay = scheduleNoQuota(6000,0,holeRaptorKill,%obj,%col);
			return;
		}	
		if(  %oScale >= %cScale+0.5 && %col.getDataBlock().shapeFile $= "Add-Ons/Bot_Raptor/Raptor.dts")
		{
			if(%col.getClassName() $= "Player" && %col.client)
			{
				%col.client.camera.setOrbitMode(%obj, %obj.getTransform(), 0, 10, 0, 1);
				%col.client.setControlObject(%col.client.camera);
				//hSpazzClick(%col,0,1);
			}
			%obj.stopHoleLoop();
			%obj.hRunAwayFromPlayer(%col);
			%obj.mountObject(%col,3);

			%obj.playThread(1,root);
			%col.playThread(0,root);
			%obj.hIgnore = %col;
			%obj.hEating = %col;
			%obj.hLastEatTime = getSimTime();
			
			%obj.invulnerable = true;
			schedule( 200, %obj, eval, %obj @ ".invulnerable = false;" );
			
			%obj.hRaptorEatDelay = scheduleNoQuota(6000,0,holeRaptorKill,%obj,%col);
			return;
		}
	}
	
	if( %checkTeam )
	{
		%obj.hAttackDamage = 35;
		%obj.hMeleeAttack( %col );
		%obj.hAttackDamage = 0;
	}
}

function holeRaptorKill(%obj,%col)
{
	if( !isObject(%obj) || %obj.isDisabled() )
		return;
		
	// we can no longer damage the guy release him
	if( miniGameCanDamage( %obj, %col ) != 1 )
	{
		%col.disMount();
		
		if( %col.client )
			%col.client.setControlObject( %col );
		
		return;
	}
		
	if(%obj.getMountedObject(0) == %col)
	{
		if(%col.getClassName() $= "Player" )
		{
			%col.damage(%obj.hFakeProjectile, %col.getposition(), 1000, $DamageType::RaptorHoleBite);
		}
		else
		{
			if(%obj.hIsInfected && getRandom(0,2))
			{
				holeZombieInfect(%obj,%col);
				%col.dismount();
				%col.playThread(0,root);
				%obj.playThread(1,root);
				%obj.hIgnore = 0;
				%obj.hEating = 0;
			}
			else
			{
				%col.kill();
				%obj.playThread(1,root);
				%obj.hEating = 0;
			}
		}
	}
	%obj.startHoleLoop();
}

function RaptorHoleBot::onRemove(%this,%obj)
{
	if( isObject( (%col = %obj.hEating) ) )
	{
		%col.playThread(0,root);
		if(%col.getClassName() $= "Player" && !%col.getControllingClient())
		{
			//cancel(%col.hSpazzClick);
			if( isObject(%col.client) )
				%col.client.setControlObject(%col);
		}
	}
}

function RaptorHoleBot::onBotFollow(%this,%obj,%targ)
{
	//Called when the target follows a player each tick, or is running away
	%obj.setCrouching(1);
}

function RaptorHoleBot::onDisabled(%this,%obj,%a)
{
	if( isObject(%obj.hEating) && %obj.hEating == %obj.getMountedObject(0) )
	{
		cancel(%obj.hRaptorEatDelay);
		%targ = %obj.hEating;
		
		%obj.hEating = 0;
		%targ.dismount();
		%targ.playThread(0,root);
		//%obj.playThread(1,root);
		if(%targ.getClassName() $= "Player")
		{
			//cancel(%targ.hSpazzClick);
			if( isObject(%targ.client) )
				%targ.client.setControlObject(%targ);
		}
	}
	%obj.playThread(0,root);
	parent::onDisabled(%this,%obj,%a);
}

function RaptorHoleBot::onBotDamage(%this,%obj,%source,%pos,%damage,%type)
{
	if( %obj.hLastEatTime+200 > getSimTime() )
		return;

	//If the Raptor has a bot in his mouth and he gets hurt randomly dismount the bot
	if( (!getRandom(0,3) || %damage >= 50 ) && isObject(%obj.hEating) && %obj.hEating == %obj.getMountedObject(0) )
	{
		cancel(%obj.hRaptorEatDelay);
		%targ = %obj.hEating;

		%obj.hEating = 0;
		%targ.dismount();
		%targ.playThread(0,root);
		%obj.playThread(1,root);
		%obj.hIgnore = 0;
		if(%targ.getClassName() $= "Player")
		{
			//cancel(%targ.hSpazzClick);
			%targ.client.setControlObject(%targ);
		}
		
		%obj.lastattacked = getsimtime()+1000;

		%obj.hRunAwayFromPlayer(%targ);
		%obj.scheduleNoQuota(2000,startHoleLoop);
	}
}

package holeRaptorPackage
{
	function Observer::onTrigger(%this, %obj, %a, %b)
	{
		%client = %obj.getControllingClient();

		if( isObject(%client.player) && %client.player.getObjectMount().hIsRaptor )
		{
			if( %b )
				%client.player.activateStuff();
				
			return;
		}

		parent::onTrigger(%this, %obj, %a, %b);
	}
};
activatePackage(holeRaptorPackage);