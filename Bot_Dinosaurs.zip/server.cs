//Base Blockhead guy
if(LoadRequiredAddOn("Bot_Hole") == $Error::None)
{
	exec("./bot_TRex.cs");
	exec("./bot_Triceratops.cs");	
	exec("./bot_Stegosaur.cs");		
	exec("./bot_Raptor.cs");
}